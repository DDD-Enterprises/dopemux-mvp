#!/usr/bin/env python3
"""Read-only static discovery for the Dopemux auditor fleet.

This script does not invoke a model, use the network, read credential files,
install software, or mutate tool configuration. It records executable/app
presence, version/help output, and boolean-only auth environment presence.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

TOOLS: dict[str, dict[str, Any]] = {
    "mechanical": {"commands": ["git", "python", "uv", "pre-commit"], "apps": []},
    "grok_build": {"commands": ["grok", "grok-build"], "apps": ["Grok.app", "Grok Build.app"]},
    "agy": {"commands": ["agy", "antigravity", "google-antigravity"], "apps": ["Antigravity.app", "Google Antigravity.app"]},
    "gemini_cli": {"commands": ["gemini"], "apps": []},
    "codex": {"commands": ["codex"], "apps": []},
    "claude_code": {"commands": ["claude"], "apps": ["Claude.app"]},
    "opencode": {"commands": ["opencode"], "apps": []},
    "openrouter": {"commands": ["openrouter"], "apps": []},
}

AUTH_ENV_KEYS = [
    "ANTHROPIC_API_KEY",
    "CLAUDE_CODE_OAUTH_TOKEN",
    "OPENAI_API_KEY",
    "CODEX_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "GOOGLE_APPLICATION_CREDENTIALS",
    "OPENROUTER_API_KEY",
    "GH_TOKEN",
    "GITHUB_TOKEN",
]

SECRET_PATTERNS = [
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bsk-proj-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{12,}\b"),
    re.compile(r"\bAIza[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{12,}\b", re.I),
    re.compile(r"(?i)(api[_-]?key|token|secret|password)\s*[:=]\s*\S+"),
]


def redact(text: str) -> str:
    home = str(Path.home())
    result = text.replace(home, "~")
    for pattern in SECRET_PATTERNS:
        result = pattern.sub("[REDACTED]", result)
    return result


def run_capture(argv: list[str], timeout: float = 10.0) -> dict[str, Any]:
    started = time.monotonic()
    try:
        proc = subprocess.run(
            argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
            env={**os.environ, "NO_COLOR": "1", "CI": "1"},
        )
        return {
            "argv": argv,
            "exit_code": proc.returncode,
            "timed_out": False,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stdout": redact(proc.stdout.decode("utf-8", errors="replace")),
            "stderr": redact(proc.stderr.decode("utf-8", errors="replace")),
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "argv": argv,
            "exit_code": None,
            "timed_out": True,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stdout": redact((exc.stdout or b"").decode("utf-8", errors="replace")),
            "stderr": redact((exc.stderr or b"").decode("utf-8", errors="replace")),
        }
    except OSError as exc:
        return {
            "argv": argv,
            "exit_code": None,
            "timed_out": False,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stdout": "",
            "stderr": redact(str(exc)),
        }


def narrow_app_search(app_names: list[str]) -> list[str]:
    if platform.system() != "Darwin" or not shutil.which("mdfind"):
        return []
    found: list[str] = []
    for app in app_names:
        receipt = run_capture(["mdfind", f"kMDItemFSName == '{app}'"], timeout=5.0)
        if receipt["exit_code"] == 0:
            for line in receipt["stdout"].splitlines():
                line = line.strip()
                if line and line.endswith(app):
                    found.append(redact(line))
    return sorted(set(found))


def tool_record(tool_id: str, spec: dict[str, Any], receipts_root: Path) -> dict[str, Any]:
    tool_dir = receipts_root / tool_id
    tool_dir.mkdir(parents=True, exist_ok=True)
    commands = []
    selected = None
    for candidate in spec["commands"]:
        path = shutil.which(candidate)
        commands.append({"candidate": candidate, "present": bool(path), "path": redact(path or "")})
        if path and selected is None:
            selected = candidate

    record: dict[str, Any] = {
        "tool_id": tool_id,
        "installation_state": "INSTALLED" if selected else ("MANUAL_APP" if spec["apps"] else "NOT_INSTALLED"),
        "selected_command": selected,
        "command_candidates": commands,
        "applications": narrow_app_search(spec["apps"]),
        "auth_environment_presence": {key: bool(os.environ.get(key)) for key in AUTH_ENV_KEYS},
        "version_receipts": [],
        "help_receipts": [],
        "static_only": True,
        "network_used": False,
        "credential_files_read": False,
        "mutation_performed": False,
    }

    if selected:
        for argv in ([selected, "--version"], [selected, "version"]):
            receipt = run_capture(list(argv))
            record["version_receipts"].append(receipt)
            (tool_dir / f"version-{len(record['version_receipts'])}.json").write_text(
                json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            if receipt["exit_code"] == 0 and receipt["stdout"].strip():
                break

        for argv in ([selected, "--help"], [selected, "help"]):
            receipt = run_capture(list(argv))
            record["help_receipts"].append(receipt)
            (tool_dir / f"help-{len(record['help_receipts'])}.json").write_text(
                json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
            )
            if receipt["exit_code"] == 0 and (receipt["stdout"].strip() or receipt["stderr"].strip()):
                break

    if record["applications"] and not selected:
        record["installation_state"] = "MANUAL_APP"

    return record


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    records = [tool_record(tool_id, spec, args.out) for tool_id, spec in TOOLS.items()]
    payload = {
        "schema_version": "1.0.0",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "host": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": platform.python_version(),
            "home_redacted": "~",
        },
        "invariants": {
            "network_used": False,
            "credential_files_read": False,
            "environment_values_recorded": False,
            "tool_installation_or_update": False,
            "model_invocation": False,
            "mutation_performed": False,
        },
        "tools": records,
    }
    out_file = args.out / "STATIC_TOOL_DISCOVERY.json"
    out_file.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(out_file)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
