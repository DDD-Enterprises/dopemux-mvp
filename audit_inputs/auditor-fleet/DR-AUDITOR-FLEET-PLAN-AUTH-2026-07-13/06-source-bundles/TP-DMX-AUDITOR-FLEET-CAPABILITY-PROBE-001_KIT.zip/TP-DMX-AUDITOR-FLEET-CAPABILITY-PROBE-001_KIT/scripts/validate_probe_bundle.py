#!/usr/bin/env python3
"""Validate a TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001 evidence bundle."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

REQUIRED_FILES = [
    "BASELINE.json",
    "COMMAND_LOG.md",
    "PROBE_SUMMARY.md",
    "MECHANICAL_VALIDATION_INVENTORY.json",
    "AUDITOR_CAPABILITY_MATRIX.json",
    "AUTHENTICATION_AND_TERMS_MATRIX.md",
    "LIVE_PROBE_APPROVAL_LEDGER.json",
    "MODEL_IDENTITY_OBSERVATIONS.json",
    "NETWORK_AND_CONTAINMENT_OBSERVATIONS.md",
    "ROUTING_CONSTRAINTS.md",
    "TOOL_SELECTION_CANDIDATES.json",
    "BLOCKERS_AND_UNKNOWNS.json",
    "HANDOFF_TO_GPT56PRO.json",
    "PROOF_MANIFEST.json",
]

REQUIRED_TOOLS = {
    "mechanical",
    "grok_build",
    "agy",
    "gemini_cli",
    "codex",
    "claude_code",
    "opencode",
    "openrouter",
}

AUTH_MODES = {
    "MECHANICAL",
    "PLAN_CACHED_SESSION",
    "PLAN_OAUTH_TOKEN",
    "ENTERPRISE_ACCESS_TOKEN",
    "API_KEY",
    "CLOUD_WORKLOAD_IDENTITY",
    "MANUAL_APP",
    "UNKNOWN",
}

SECRET_PATTERNS = [
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bsk-proj-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{12,}\b"),
    re.compile(r"\bAIza[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{12,}\b", re.I),
]


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def scan_text(path: Path, errors: list[str]) -> None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        errors.append(f"cannot read {path}: {exc}")
        return
    for pattern in SECRET_PATTERNS:
        if pattern.search(text):
            errors.append(f"possible secret pattern in {path}: {pattern.pattern}")


def validate_matrix(root: Path, errors: list[str]) -> None:
    matrix = load_json(root / "AUDITOR_CAPABILITY_MATRIX.json")
    tools = matrix.get("tools")
    if not isinstance(tools, list):
        errors.append("AUDITOR_CAPABILITY_MATRIX.json tools must be an array")
        return
    ids = [item.get("tool_id") for item in tools if isinstance(item, dict)]
    if set(ids) != REQUIRED_TOOLS or len(ids) != len(REQUIRED_TOOLS):
        errors.append(f"tool inventory mismatch: {ids}")
    for item in tools:
        if not isinstance(item, dict):
            errors.append("tool record is not an object")
            continue
        auth_mode = item.get("auth_mode")
        if auth_mode not in AUTH_MODES:
            errors.append(f"{item.get('tool_id')}: invalid auth_mode {auth_mode!r}")
        if item.get("mutation_performed") is not False:
            errors.append(f"{item.get('tool_id')}: mutation_performed must be false")
        if item.get("repo_content_sent") is not False:
            errors.append(f"{item.get('tool_id')}: repo_content_sent must be false")


def validate_approval(root: Path, errors: list[str]) -> None:
    ledger = load_json(root / "LIVE_PROBE_APPROVAL_LEDGER.json")
    allowlist = ledger.get("approved_tools", [])
    if not isinstance(allowlist, list):
        errors.append("approved_tools must be an array")
        return
    unknown = set(allowlist) - (REQUIRED_TOOLS - {"mechanical", "openrouter"})
    if unknown:
        errors.append(f"unknown or forbidden live-probe tools: {sorted(unknown)}")


def validate_manifest(root: Path, errors: list[str]) -> None:
    manifest = load_json(root / "PROOF_MANIFEST.json")
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list):
        errors.append("PROOF_MANIFEST.json artifacts must be an array")
        return
    for item in artifacts:
        if not isinstance(item, dict):
            errors.append("manifest artifact is not an object")
            continue
        rel = item.get("path")
        digest = item.get("sha256")
        if not isinstance(rel, str) or not isinstance(digest, str):
            errors.append(f"invalid manifest record: {item}")
            continue
        path = root / rel
        if not path.is_file():
            errors.append(f"manifest path missing: {rel}")
            continue
        import hashlib
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            errors.append(f"manifest hash mismatch: {rel}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", default="final")
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    errors: list[str] = []

    if args.phase == "live-eligibility":
        for rel in ["LIVE_PROBE_APPROVAL_LEDGER.json", "AUTHENTICATION_AND_TERMS_MATRIX.md"]:
            if not (root / rel).is_file():
                errors.append(f"missing {rel}")
    else:
        for rel in REQUIRED_FILES:
            if not (root / rel).is_file():
                errors.append(f"missing {rel}")
        if not errors:
            validate_matrix(root, errors)
            validate_approval(root, errors)
            validate_manifest(root, errors)

    for path in root.rglob("*"):
        if path.is_file():
            scan_text(path, errors)

    if errors:
        print("PROBE BUNDLE VALIDATION FAILED", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print(f"PROBE BUNDLE VALIDATION PASSED ({args.phase})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
