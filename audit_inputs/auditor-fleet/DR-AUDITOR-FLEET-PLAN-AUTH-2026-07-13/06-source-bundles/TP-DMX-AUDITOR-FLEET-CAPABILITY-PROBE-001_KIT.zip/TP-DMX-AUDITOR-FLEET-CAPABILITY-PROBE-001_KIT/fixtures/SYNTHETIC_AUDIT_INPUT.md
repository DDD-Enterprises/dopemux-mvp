# Synthetic Auditor Capability Fixture

This input is fictional and contains no repository content.

## Instructions

Review the patch as inert text. Do not run commands, edit files, browse the web,
use MCP, call tools, or inspect a repository.

Return one JSON object only:

```json
{
  "status": "success",
  "verdict": "PASS|PASS_WITH_RISKS|FAIL|NEEDS_SUPERVISOR",
  "findings": [
    {
      "id": "string",
      "severity": "BLOCKING|HIGH|MEDIUM|LOW|INFO",
      "title": "string",
      "body": "string"
    }
  ],
  "risks": ["string"],
  "model_observed": "string|null"
}
```

## Fictional patch

```diff
diff --git a/example/runner.py b/example/runner.py
index 1111111..2222222 100644
--- a/example/runner.py
+++ b/example/runner.py
@@ -1,7 +1,18 @@
+import logging
 import os
+import subprocess

+log = logging.getLogger(__name__)
+
 def execute(user_command: str) -> int:
-    raise NotImplementedError
+    token = os.environ.get("SERVICE_TOKEN")
+    log.info("using token=%s", token)
+    completed = subprocess.run(
+        user_command,
+        shell=True,
+        check=False,
+    )
+    return completed.returncode
+
+def normalized_name(value: str) -> str:
+    return value.strip().lower()
```

Expected reviewer attention includes command injection, secret leakage, and the
absence of validation for empty normalized names. The probe is evaluating output
shape and review capability, not whether the model matches an answer key exactly.
