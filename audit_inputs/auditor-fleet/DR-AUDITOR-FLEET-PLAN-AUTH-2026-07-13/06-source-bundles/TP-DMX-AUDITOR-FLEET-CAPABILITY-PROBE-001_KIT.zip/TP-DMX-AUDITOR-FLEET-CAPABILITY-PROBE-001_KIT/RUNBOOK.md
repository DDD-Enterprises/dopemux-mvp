# Auditor Fleet Capability Probe Runbook

## 1. Create the worktree

```bash
cd /Users/hue/code/dopemux-mvp
git fetch origin
git worktree add   -b audit/auditor-fleet-capability-probe-001   /Users/hue/code/dopemux-mvp-wt-auditor-fleet-probe-001   origin/main
cd /Users/hue/code/dopemux-mvp-wt-auditor-fleet-probe-001
```

## 2. Install the packet and helper assets into the worktree

Replace `/path/to/KIT` with the extracted kit path.

```bash
mkdir -p proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/{tools,fixtures,templates,RAW_RECEIPTS/static,RAW_RECEIPTS/live,RAW_RECEIPTS/manual}

cp /path/to/KIT/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.json   task-packets/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.json
cp /path/to/KIT/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.md   task-packets/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.md
cp /path/to/KIT/scripts/static_probe.py   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/tools/static_probe.py
cp /path/to/KIT/scripts/validate_probe_bundle.py   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/tools/validate_probe_bundle.py
cp /path/to/KIT/fixtures/SYNTHETIC_AUDIT_INPUT.md   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/fixtures/SYNTHETIC_AUDIT_INPUT.md
cp /path/to/KIT/templates/LIVE_PROBE_RECEIPT.template.json   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/templates/LIVE_PROBE_RECEIPT.template.json
cp /path/to/KIT/templates/MANUAL_APP_RECEIPT.template.json   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/templates/MANUAL_APP_RECEIPT.template.json
```

Update `task-packets/INDEX.md` with one Active row.

## 3. Choose live probes explicitly

Default is none:

```bash
export LIVE_PROBE_TOOL_ALLOWLIST=""
```

Example plan-backed candidates:

```bash
export LIVE_PROBE_TOOL_ALLOWLIST="claude_code,codex,gemini_cli,opencode"
```

This environment variable authorizes consideration only. Unsafe or ambiguous tools still remain NOT_RUN.

## 4. Run the static probe

```bash
python proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/tools/static_probe.py   --out proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/RAW_RECEIPTS/static
```

## 5. Execute the packet

Paste `prompts/CODEX_EXECUTION_PROMPT.md` into the chosen implementer session.
The implementer must derive tool-specific live commands from captured local help.

## 6. Validate

```bash
python proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/tools/validate_probe_bundle.py   proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001

uv run --frozen dopemux orchestrator packet validate   task-packets/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.json

git diff --check
git status --short --branch
```

Do not push or open a PR until the evidence is reviewed for accidental credential leakage.
