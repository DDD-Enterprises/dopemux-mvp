---
id: TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001
title: Auditor Fleet Capability And Plan-Authentication Probe
type: explanation
owner: '@hu3mann'
author: GPT-5.6 Thinking
date: '2026-07-13'
last_review: '2026-07-13'
next_review: '2026-08-12'
prelude: Read-only capability and plan-authentication probe for the Dopemux auditor fleet.
---
# Task Packet: TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001

## Status

`READY_FOR_LOCAL_EXECUTION`

This packet gathers evidence. It does **not** implement the audit broker, a GitHub custom runner, routing automation, credential transport, or an audit-policy change.

## Objective

Produce a host-grounded, reproducible capability and authentication evidence set for:

1. mechanical validation only;
2. Grok Build;
3. AGY / Google Antigravity;
4. Gemini CLI;
5. Codex;
6. Claude Code;
7. OpenCode;
8. OpenRouter as an optional API fallback.

The output must let a clean-room GPT-5.6 Pro synthesis design the audit broker and routing policy without guessing which tools can actually run through plan-backed authentication.

## Why This Packet Exists Now

The current trusted GitHub audit workflow can bind an audit to an exact PR head and emit fail-closed proof, but the GitHub-hosted runner does not possess the selected plan-authenticated CLI. Provisioning a premium API key would defeat the cost objective. Before choosing a local broker or custom runner architecture, the project needs direct evidence about each tool's:

- installed surface;
- plan-authentication mechanism;
- headless behavior;
- structured output;
- read-only controls;
- configuration isolation;
- credential isolation;
- model identity;
- network posture;
- runner suitability.

Vendor documentation is supporting evidence. Local runtime observations are the authority for the host being probed.

## Risk Level

`MEDIUM`

The packet is read-only with respect to runtime code, but it touches persistent model credentials indirectly by exercising already-authenticated sessions. The main hazards are accidental credential exposure, plan-versus-API billing confusion, inherited tool configuration, and allowing an audit tool to mutate files or execute commands.

## Task Class

`architecture-sensitive evidence collection`

## Authority And Claim Labels

Every material result must use one of:

- **OBSERVED**: directly captured from the local runtime, CLI output, process behavior, repository, or generated receipt.
- **CLAIMED**: asserted by an operator, CLI branding, configuration, or vendor text but not independently demonstrated.
- **INFERRED**: a bounded conclusion from observed evidence.
- **PROPOSED**: a design candidate for later synthesis.
- **UNKNOWN**: insufficient evidence.
- **CONFLICTING**: credible evidence disagrees.

No tool may be promoted to an automated passing audit route from a CLAIMED or UNKNOWN capability.

## Scope

### IN

- current `origin/main` repository inspection;
- deterministic mechanical-validator census;
- executable/application discovery;
- version and help capture;
- boolean-only authentication environment checks;
- operator-declared subscription state;
- safe-mode and structured-output discovery;
- one synthetic live probe per explicitly approved, plan-backed tool;
- manual-app receipt templates for Grok Build and AGY;
- model identity and containment observations;
- proof bundle and GPT-5.6 Pro handoff.

### OUT

- audit-broker implementation;
- GitHub self-hosted runner registration;
- runner groups, labels, or service installation;
- secrets or credential changes;
- CLI installation, update, login, logout, or token refresh;
- provider API-key calls;
- OpenRouter live calls;
- repository code audits;
- PR #1046 reruns;
- branch protection;
- PR Steward changes;
- audit-policy changes;
- automated model routing;
- benchmark certification;
- production or release authorization.

## Invariants

1. **No credential material enters evidence.**
   Never record secret values, credential contents, raw cookies, keychain exports, bearer headers, auth databases, API keys, or hashes of secret-bearing files.

2. **Plan usage must be proven, not assumed.**
   A tool is `PLAN_CACHED_SESSION` or `PLAN_OAUTH_TOKEN` only when the invocation path and local evidence show that an API-key route is not active. Otherwise use `UNKNOWN`.

3. **No installs or authentication mutations.**
   Missing or unauthenticated tools are evidence. Do not install, update, login, logout, refresh, or copy credentials.

4. **No repository content in live probes.**
   Use only the supplied synthetic fixture.

5. **No agentic mutation.**
   Live probes must disable edits, shell execution, MCP, web browsing, hooks, plugins, skills, memory, subagents, and repository instructions whenever the tool exposes such controls. If safe disablement cannot be proven, do not run.

6. **One invocation per approved tool.**
   No retries that consume plan quota unless a supervisor explicitly authorizes a targeted rerun.

7. **Unknown stays blocked.**
   Ambiguous auth, model identity, billing, containment, or output parsing cannot become a passing route.

8. **Bridges are not authority.**
   PAL, OpenCode, wrappers, brokers, and future runner adapters can carry evidence but cannot author canonical approval by themselves.

9. **No final architecture in this packet.**
   The matrix may contain candidate roles, but the final routing architecture belongs to the later GPT-5.6 Pro synthesis.

## Required Confidence Gates

| Gate | Required confidence |
|---|---|
| Repository and host identity | HIGH |
| Static tool discovery | VERIFIED |
| Auth-mode classification | HIGH for plan-backed, otherwise UNKNOWN |
| Live-probe eligibility | HIGH |
| Live receipt | VERIFIED or NOT_RUN |
| Final capability matrix | VERIFIED as evidence capture |
| Architecture decision | NOT_STARTED |

## Authentication Classes

Use exactly:

- `MECHANICAL`
- `PLAN_CACHED_SESSION`
- `PLAN_OAUTH_TOKEN`
- `ENTERPRISE_ACCESS_TOKEN`
- `API_KEY`
- `CLOUD_WORKLOAD_IDENTITY`
- `MANUAL_APP`
- `UNKNOWN`

`API_KEY` routes are observed but not exercised in this packet.

## Required Tool Records

Each tool record must include:

```text
tool_id
display_name
tool_class
installation_state
command_or_application
version
version_confidence
headless_support
structured_output_support
model_selection_support
requested_model
observed_model
model_identity_confidence
auth_mode
auth_evidence_refs
plan_usage_confidence
credential_isolation
config_isolation
mcp_disablement
hooks_disablement
plugins_disablement
skills_disablement
subagent_disablement
shell_disablement
file_write_disablement
web_disablement
network_posture
timeout_control
exit_code_contract
live_probe_eligible
live_probe_status
mutation_performed
repo_content_sent
findings
risks
unknowns
```

## Mechanical Validation Lane

Inventory current canonical validators for:

- repository identity;
- packet schema;
- proof schema;
- JSON Schema;
- changed-file allowlists;
- `git diff --check`;
- archive and manifest hashing;
- secret scanning;
- docs placement and filename hygiene;
- focused tests;
- exact PR/head identity;
- PR Steward readiness.

For every validator, record whether it:

- reads only;
- writes temp files;
- can mutate repository files;
- provides machine-readable output;
- has stable exit codes;
- has governance authority;
- can satisfy a no-LLM evidence-only lane.

Do not run auto-fixing pre-commit hooks during the probe.

## Static Tool Discovery

Run the supplied `static_probe.py`. It:

- uses `command -v`-equivalent discovery;
- captures version and help output with timeouts;
- searches narrowly for known desktop application names on macOS;
- records known auth environment variables as boolean presence only;
- redacts the home directory and common secret patterns;
- does not call a model;
- does not read credential files;
- does not use the network;
- does not install anything.

Required tool IDs:

```text
mechanical
grok_build
agy
gemini_cli
codex
claude_code
opencode
openrouter
```

## Live-Probe Approval Gate

Live probes are disabled by default.

Before execution, populate:

```text
LIVE_PROBE_TOOL_ALLOWLIST
```

with a comma-separated subset, such as:

```text
claude_code,codex,gemini_cli,opencode
```

A listed tool still must pass the safe-live-probe eligibility gate. The allowlist is authorization, not proof of safety.

### Eligibility requirements

A live probe may run only when all are HIGH or VERIFIED:

- executable or manual app is present;
- current auth mode is plan-backed or manual-app;
- API-key environment is absent for the selected invocation;
- no login or refresh is required;
- exact non-interactive invocation is derived from observed local help;
- output can be captured;
- timeout is enforceable;
- file writes are disabled or sandboxed to a disposable directory;
- shell, MCP, hooks, plugins, skills, web, and subagents are disabled or proven absent;
- repository content is not included;
- requested model is explicit where supported;
- model identity limitations are recorded.

## Synthetic Live Probe

Use only `fixtures/SYNTHETIC_AUDIT_INPUT.md`.

The fixture contains a tiny fictional patch with:

- command injection;
- secret logging;
- a missing validation edge case.

The requested response is strict JSON:

```json
{
  "status": "success",
  "verdict": "PASS|PASS_WITH_RISKS|FAIL|NEEDS_SUPERVISOR",
  "findings": [
    {
      "id": "string",
      "severity": "BLOCKING|HIGH|MEDIUM|LOW|INFO",
      "title": "string",
      "body": "string"
    }
  ],
  "risks": ["string"],
  "model_observed": "string|null"
}
```

Malformed output is a capability result. Do not repair it manually and pretend the tool emitted valid JSON.

## Tool-Specific Posture

### Claude Code

Probe the installed Claude Code CLI only. A plan-backed classification requires evidence that the live invocation uses the current subscription/OAuth session and not `ANTHROPIC_API_KEY`. Record whether local instructions, MCP, hooks, plugins, skills, memory, and subagents can be disabled for an unattended run.

### Codex

Probe the installed Codex CLI only. Record ChatGPT-plan versus API-key posture, headless execution, sandbox and approval settings, JSON event output, model selection, and credential portability to a dedicated runner account. Codex may coordinate this packet but cannot independently certify its own result.

### Gemini CLI

Probe the installed Gemini CLI only. Record cached Google-login versus API-key posture, plan/approval mode, telemetry control, structured output, model selection, and configuration isolation.

### OpenCode

Probe OpenCode with its actual configured provider. Record the upstream provider and auth mode. Do not infer plan usage from OpenCode branding. If it uses ChatGPT, Copilot, or another subscription-backed provider, capture that distinction. Do not route a Claude consumer subscription through OpenCode.

### Grok Build

Treat as `MANUAL_APP` or `UNKNOWN` unless a real local command or automation entrypoint is observed. A UI-only receipt must record displayed model, plan/account surface, manual invocation steps, output capture method, and inability to prove unattended containment.

### AGY / Google Antigravity

Keep AGY distinct from Gemini CLI. Record whether AGY exposes any supported automation entrypoint. Otherwise classify it as a manual embedded-auditor surface and capture a manual receipt only.

### OpenRouter

Static inspection only. Record client/library availability, environment-variable presence, existing repository contracts, model/provider pinning capability, price caps, data-policy controls, and zero-data-retention support where locally configured. Do not call the API.

## Required Outputs

Under:

```text
proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001/
```

produce:

```text
BASELINE.json
COMMAND_LOG.md
PROBE_SUMMARY.md
MECHANICAL_VALIDATION_INVENTORY.json
AUDITOR_CAPABILITY_MATRIX.json
AUTHENTICATION_AND_TERMS_MATRIX.md
LIVE_PROBE_APPROVAL_LEDGER.json
MODEL_IDENTITY_OBSERVATIONS.json
NETWORK_AND_CONTAINMENT_OBSERVATIONS.md
ROUTING_CONSTRAINTS.md
TOOL_SELECTION_CANDIDATES.json
BLOCKERS_AND_UNKNOWNS.json
HANDOFF_TO_GPT56PRO.json
PROOF_MANIFEST.json
RAW_RECEIPTS/
  static/
  live/
  manual/
tools/
  static_probe.py
  validate_probe_bundle.py
fixtures/
  SYNTHETIC_AUDIT_INPUT.md
templates/
  LIVE_PROBE_RECEIPT.template.json
  MANUAL_APP_RECEIPT.template.json
```

## GPT-5.6 Pro Handoff Requirements

`HANDOFF_TO_GPT56PRO.json` must request:

1. local Audit Broker architecture;
2. optional dedicated self-hosted runner architecture;
3. threat and trust model;
4. authentication and credential-isolation model;
5. request/result/proof contracts;
6. risk and complexity routing policy;
7. mechanical-only lane;
8. plan-backed CLI adapter boundaries;
9. OpenRouter fallback policy;
10. exact-head GitHub and PR Steward integration;
11. state machine;
12. disablement and rollback;
13. phased migration;
14. implementation task-packet series;
15. a verdict of:
   - `READY_FOR_INDEPENDENT_AUDIT`
   - `READY_AFTER_BLOCKING_REPAIRS`
   - `BLOCKED_INSUFFICIENT_EVIDENCE`
   - `REQUIRES_RESYNTHESIS`

The handoff must tell GPT-5.6 Pro not to infer missing credentials, plan rights, or containment.

## Output Capture Rules

Return verbatim:

- Git status before and after;
- current `origin/main` SHA;
- tool discovery outputs;
- every executed command;
- exit codes;
- timeouts;
- raw stdout and stderr after redaction;
- exact live-probe allowlist;
- exact redacted live invocations;
- live probe durations;
- model requested and model observed;
- files created;
- `git diff --stat`;
- `git diff`;
- bundle-validation output;
- all NOT_RUN and BLOCKED reasons.

## Acceptance Criteria

The packet is complete only when:

1. all eight tool classes have capability records;
2. no secret value or credential-file content is present;
3. no tool was installed, updated, logged in, logged out, or refreshed;
4. no API-key or OpenRouter live call occurred;
5. every live probe was pre-authorized and plan-backed;
6. no repository content was sent to a model;
7. every executed probe used the synthetic fixture;
8. every executed probe has a receipt with exact-head-independent synthetic scope;
9. every missing or unsafe tool is explicitly NOT_RUN or BLOCKED;
10. model identity uncertainty is preserved;
11. the mechanical-validation lane is fully inventoried;
12. the final matrix separates OBSERVED capability from PROPOSED routing;
13. the proof bundle passes `validate_probe_bundle.py`;
14. the GPT-5.6 Pro handoff is self-contained and hash-bound;
15. no architecture implementation began.

## Rollback

Because outputs are evidence-only:

```bash
rm -rf proof/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001
git restore -- task-packets/INDEX.md
rm -f task-packets/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.json
rm -f task-packets/TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.md
```

Do not delete, revoke, or modify provider credentials as rollback for this packet.

## Stop Conditions

Stop immediately if:

- a secret value, auth token, cookie, key, or credential content enters output;
- a tool tries to authenticate, refresh, open a login browser, or modify auth state;
- a live invocation may use metered API billing when plan usage was expected;
- a tool cannot disable or contain file writes, shell, MCP, hooks, plugins, skills, web, or subagents;
- a tool attempts repository mutation;
- a tool attempts GitHub mutation;
- repository content is included in a model prompt;
- an unapproved tool is invoked;
- a second live invocation would be needed;
- an external API call is required;
- exact output cannot be redacted safely;
- work escapes the allowlist;
- current repo identity is ambiguous;
- evidence becomes contradictory enough that the matrix cannot preserve both sides.

When stopped, return:

- the exact stop condition;
- commands already run;
- artifacts already created;
- evidence needed next;
- whether bounded vendor research or supervisor disposition is required.

## Final Disposition

Successful completion means:

```text
CAPABILITY_PROBE: VERIFIED
AUDIT_BROKER_ARCHITECTURE: NOT_STARTED
CUSTOM_RUNNER_IMPLEMENTATION: NOT_STARTED
NEXT_ACTION: GPT-5.6 Pro synthesis using HANDOFF_TO_GPT56PRO.json
```
