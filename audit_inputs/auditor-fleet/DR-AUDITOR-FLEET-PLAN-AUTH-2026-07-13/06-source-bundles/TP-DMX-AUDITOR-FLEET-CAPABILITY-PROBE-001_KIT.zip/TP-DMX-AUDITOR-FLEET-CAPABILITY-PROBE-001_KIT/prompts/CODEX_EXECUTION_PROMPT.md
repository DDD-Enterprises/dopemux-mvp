ROLE
You are the bounded implementer for TP-DMX-AUDITOR-FLEET-CAPABILITY-PROBE-001.

MISSION
Execute the packet exactly. Gather local evidence about mechanical validation,
Grok Build, AGY, Gemini CLI, Codex, Claude Code, OpenCode, and OpenRouter fallback.

START
1. Read the packet JSON and Markdown in full.
2. Read AGENTS.md, RULES.md, docs/ops/embedded-audit.md,
   tools/auditor_router/pal_clink.py, and scripts/audit/pal_clink_runner.py.
3. Use a clean dedicated worktree based on current origin/main.
4. Copy the supplied scripts, fixture, and templates into the packet proof directory.

HARD LIMITS
- Do not install or update software.
- Do not login, logout, refresh, generate, copy, or inspect credentials.
- Do not print environment values.
- Do not make API-key or OpenRouter calls.
- Do not send repository content to any model.
- Do not run a live tool unless it appears in LIVE_PROBE_TOOL_ALLOWLIST and
  independently passes the eligibility gate.
- Do not guess CLI flags. Derive invocations from captured local help.
- Do not allow edits, shell, MCP, hooks, plugins, skills, memory, subagents,
  web browsing, or GitHub mutation.
- Use one synthetic invocation maximum per approved tool.
- Mark unsafe or ambiguous tools NOT_RUN or BLOCKED.
- Do not implement the audit broker or custom runner.

OUTPUT
Produce every required artifact, validate the proof bundle, and return:
- summary
- evidence ledger
- exact commands and exit codes
- live probe approvals
- observed auth modes
- findings
- blockers and unknowns
- git status before/after
- git diff --stat
- git diff
- final disposition

SUCCESS
CAPABILITY_PROBE=VERIFIED
AUDIT_BROKER_ARCHITECTURE=NOT_STARTED
NEXT_ACTION=GPT-5.6 Pro synthesis using HANDOFF_TO_GPT56PRO.json
