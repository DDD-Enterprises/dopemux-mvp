# Deep Research Operator Paste

Use ChatGPT Deep Research.

Campaign: `DR-AUDITOR-FLEET-PLAN-AUTH-2026-07-13`

Upload:

- this entire campaign kit;
- the completed local capability-probe outputs listed in `START_HERE.md`.

Read:

- `MASTER-PROMPT.md`;
- `SOURCE-POLICY.md`;
- `RUN-CONTROL.md`;
- the selected track file under `tracks/`.

Run only the selected track.

Do not perform implementation, account login, API calls, repository mutation, or final
architecture synthesis.

Return the required Markdown report and JSON findings file. Preserve all UNKNOWN,
CONFLICTING, and NOT_RUN outcomes.
