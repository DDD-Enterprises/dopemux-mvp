# Input Summary for GPT-5.5 Pro — PCP/DCP Full Architecture Regeneration

## Current hypothesis

The intended architecture is a **three-layer model**:

1. **PCP Core** — reusable project-control substrate (schemas, evidence export contracts, red-lane policy, proof pointers, supervisor adjudication) usable by any Git repo
2. **DCP / Dopemux extension** — Dopemux-specific control plane built on PCP Core (DCP routing, PR Steward, Dopetask handoff, model routing, MCP surfaces)
3. **dNh extension** — CRM control plane as first project adapter target, not universal system

PR #925 (`codex/tp-dmx-pcp-architecture-validation-0001`) is the primary planning artifact: 32 files, +3040 lines, fixture-only validation with 11 JSON schemas and three fixture packs (minimal, dopemux, dnh_crm). Verdict posture: `ARCHITECTURE_CONFIRMED_WITH_CORRECTIONS` in prose, but governance remains `NEEDS_SUPERVISOR`.

## Evidence included

| Category | Key paths | Notes |
|----------|-----------|-------|
| PR #925 live state | `PR_925/PR_VIEW.json`, `DIFF_FULL.patch`, `REVIEW_THREADS_AND_REVIEWS.json` | Head `68b8fd17`, draft, MERGEABLE, CI green |
| PR #931 live state | `PR_931/PR_VIEW.json`, `DIFF_FULL.patch` | Head `017dc52b`, **CLOSED** (not merged), OpenClaw routing contracts |
| PCP schemas/fixtures | `PCP_ARTIFACTS/schemas/`, `PCP_ARTIFACTS/fixtures/` | 11 schemas + 3 fixture packs |
| PCP validation | `PCP_ARTIFACTS/reports/project-control-plane/validation/` | E2E dry-run, architecture report, auditor report |
| Prior adjudication | `ADJUDICATION_OUTPUTS/SUPERVISOR_INTAKE_SUMMARY.md` | PR #925 supervisor intake from prior pack |
| DCP runtime/docs | `DCP_EXTENSION_INPUTS/` | `src/dopemux/dcp/`, DCP schemas, routing CLI |
| dNh materials | `DNH_EXTENSION_INPUTS/` | Fixture-only; no live dNh repo |
| Authority | `REPO_AUTHORITY_DOCS/AGENTS.md`, system docs | Truth order, boundaries |
| Governance | `GOVERNANCE_CONTRACTS/dopetask-canonical-spec.json` | Task packet + proof contracts |
| OpenClaw routing | `OPENCLAW_ROUTING_INPUTS/`, `PR_931/DIFF_FULL.patch` | Policy YAML on branch; contracts on PR #931 only |

## Known conflicts (evidence-supported)

1. **PCP Core desired as parent, but PR #925 names "Dopemux Project Control Plane"** — ownership matrix and docs frame generic PCP + adapters, but naming and some schema fields (Dopetask, Task Orchestrator) are Dopemux-shaped.
2. **PCP Core desired as generic, but core schemas require Dopetask / Task Orchestrator fields** — `dopetask_packet_mapping`, `orchestrator_item`, executor schemas embed Dopemux execution surfaces.
3. **Extension contract schema missing** — no `pcp_extension_manifest.schema.json` or equivalent observed.
4. **Authority-map schema missing** — ownership matrix is markdown prose, not machine schema.
5. **PR #925 negative tests asserted, not executed** — `E2E_DRY_RUN_RESULT.json` uses `asserted_result`; no exporter/classifier runtime.
6. **PR #925 proof freshness tension** — repair commit `68b8fd17` updated `after_sha` and dNh `policy_ref`; copied `PCP_ARTIFACTS/proof/PROOF.json` may reflect pre-repair `84149bced`. Live head is authoritative via `PR_925/`.
7. **PR #931 contracts green but PR closed** — CI SUCCESS at capture; PR #926 merged related contracts; PR #931 superseded/closed with review threads mostly resolved.
8. **Opus vs Pro adjudication not reconciled** — Opus adversarial audit confirms `NEEDS_SUPERVISOR`; no standalone GPT-5.5 Pro PCP architecture adjudication file found; reconciliation is **UNKNOWN**.

## Major unresolved questions

- What belongs in PCP Core vs DCP extension vs project extension (dNh)?
- Is PR #925 salvageable as planning-only, or must schemas be split/repaired first?
- What is correct build order: PCP Core extraction → DCP extension → dNh adapter exporter?
- What proof gates are required before `LIVE_WRITE_READY` / live writes?
- Should `architecture_verdict` field be relabeled (`ARCHITECTURE_SHAPE_PLAUSIBLE_PENDING_AUDIT`)?
- Is a generic PCP exporter a prerequisite to PR #925 acceptance or a follow-on packet?

## Likely next decisions Pro must make

1. **Boundary cut** — enumerate PCP Core minimal schema set vs Dopemux-only extensions
2. **PR #925 salvage map** — keep schemas/fixtures/ownership-matrix; repair Dopemux-coupled fields; defer exporter
3. **Schema migration plan** — rename/move `schemas/project_control_plane/` → core + extension manifests
4. **Build order DAG** — PCP Core package → DCP extension wiring → dNh fixture exporter → live validation
5. **Proof gates** — fixture replay harness, exporter dry-run, Supervisor acceptance, benchmark certification (from PR #931 contracts)
6. **PR disposition** — #925 remain draft until exporter packet; #931 reopen or cherry-pick contracts from #926 lineage