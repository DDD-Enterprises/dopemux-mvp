# Evidence Ledger

| Evidence | Path | Status | Why included | Caveat |
|----------|------|--------|--------------|--------|
| PR #925 metadata | `PR_925/PR_VIEW.json` | CAPTURED | Live GitHub state for PCP validation PR | Draft, not merge-ready |
| PR #925 full diff | `PR_925/DIFF_FULL.patch` | CAPTURED | Complete file-level changes for salvage analysis | 142k patch; head `68b8fd17` |
| PR #925 changed files | `PR_925/CHANGED_FILES.txt` | CAPTURED | Quick inventory (32 files) | — |
| PR #925 checks | `PR_925/CHECKS.json` | CAPTURED | CI/statusCheckRollup at capture | Green ≠ acceptance |
| PR #925 reviews | `PR_925/REVIEW_THREADS_AND_REVIEWS.json` | CAPTURED | Codex P2 threads (outdated after repair) | Threads formally unresolved |
| PR #925 body | `PR_925/PR_BODY.md` | CAPTURED | NEEDS_SUPERVISOR posture, Opus addendum | — |
| PR #931 metadata | `PR_931/PR_VIEW.json` | CAPTURED | OpenClaw/DCP routing contracts PR | **CLOSED**, not merged |
| PR #931 full diff | `PR_931/DIFF_FULL.patch` | CAPTURED | Contracts-only routing artifacts | Not on current branch |
| PR #931 reviews | `PR_931/REVIEW_THREADS_AND_REVIEWS.json` | CAPTURED | Review thread resolution state | Mostly resolved |
| Prior supervisor intake | `ADJUDICATION_OUTPUTS/SUPERVISOR_INTAKE_SUMMARY.md` | CAPTURED | Prior PR #925 adjudication prompt context | Not Opus/Pro full adjudication |
| Prior risk ledger | `ADJUDICATION_OUTPUTS/UNKNOWN_AND_RISK_LEDGER.md` | CAPTURED | Open findings H1, AAA-A, AAA-B | — |
| DCP open PR ledger | `ADJUDICATION_OUTPUTS/DCP_OPEN_PR_LEDGER.json` | CAPTURED | Lane mapping for PR #925 | — |
| PCP schemas (11) | `PCP_ARTIFACTS/schemas/` | CAPTURED | Core contract surface from PR #925 | Dopemux-coupled fields present |
| PCP fixtures (3 packs) | `PCP_ARTIFACTS/fixtures/` | CAPTURED | minimal, dopemux, dnh_crm | Asserted data only |
| PCP proof bundle | `PCP_ARTIFACTS/proof/TP-DMX-PCP-ARCHITECTURE-VALIDATION-0001/` | CAPTURED | PROOF.json, AUDITOR_REPORT.md | May lag PR head repair commit |
| PCP validation reports | `PCP_ARTIFACTS/reports/project-control-plane/validation/` | CAPTURED | E2E dry-run, architecture report | Fixture-only |
| DCP reference docs | `DCP_EXTENSION_INPUTS/docs/03-reference/dcp/` | CAPTURED | DCP architecture synthesis, artifacts | — |
| DCP schemas | `DCP_EXTENSION_INPUTS/schemas/dcp/` | CAPTURED | Existing DCP contract surfaces | — |
| DCP runtime | `DCP_EXTENSION_INPUTS/src/dopemux/dcp/` | CAPTURED | Observed DCP implementation | Extension boundary TBD |
| Routing CLI/config | `DCP_EXTENSION_INPUTS/src/dopemux/routing_*.py` | CAPTURED | Model routing surfaces | — |
| Dopetask runtime | `DCP_EXTENSION_INPUTS/scripts/dopetask` | CAPTURED | Execution handoff surface | — |
| Model routing policy | `OPENCLAW_ROUTING_INPUTS/config/ai/model-routing.policy.yaml` | CAPTURED | Multi-model routing authority | Contracts in PR #931 not on branch |
| dNh supervisor doc | `DNH_EXTENSION_INPUTS/dnh-crm-supervisor.md` | CAPTURED | dNh adapter target framing | — |
| dNh fixture pack | `DNH_EXTENSION_INPUTS/dnh_crm_fixture/` | CAPTURED | First adapter target fixtures | No live dNh repo |
| AGENTS.md | `REPO_AUTHORITY_DOCS/AGENTS.md` | CAPTURED | Truth order, PAL chains, boundaries | — |
| System authority docs | `REPO_AUTHORITY_DOCS/docs/03-reference/systems/` | CAPTURED | Per-system boundary truth | Partial set |
| Dopetask canonical spec | `GOVERNANCE_CONTRACTS/docs/03-reference/spec/dopetask/dopetask-canonical-spec.json` | CAPTURED | Task packet validation | — |
| Proof contracts | `GOVERNANCE_CONTRACTS/docs/03-reference/governance/` | CAPTURED | Proof bundle requirements | — |
| GitHub PR sample | `CURRENT_GITHUB_STATE/open_prs_sample.json` | CAPTURED | Recent lane context | Sample only |
| Opus PCP adjudication | — | MISSING | Required per spec | Only adversarial audit in PR #925 |
| GPT-5.5 Pro PCP adjudication | — | MISSING | Required per spec | Not found as standalone file |
| Opus+Pro reconciliation | — | MISSING | Required per spec | UNKNOWN |
| Full arch regeneration prompt (prior) | — | MISSING | Prior prompt if present | Not found |
| PCP extension contract schema | — | MISSING | Extension boundary definition | Blocks clean core cut |
| PCP authority-map schema | — | MISSING | Machine-checkable ownership | Markdown only |
| Generic PCP exporter runtime | — | MISSING | Behavior proof | Fixture-only by design |
| dNh live exporter | — | MISSING | Live adapter validation | Out of scope |
| OpenClaw contracts on branch | `contracts/openclaw-dcp-routing/` | MISSING on branch | In PR #931/#926 diff only | Use PR_931 patch |