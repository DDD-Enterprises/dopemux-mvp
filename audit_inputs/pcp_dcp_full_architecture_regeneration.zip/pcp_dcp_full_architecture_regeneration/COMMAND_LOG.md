# Command Log — TP-DMX-PCP-DCP-FULL-ARCH-INPUTS-0001

Assembly performed read-only. Exit codes recorded at capture time.

## Preflight

```bash
git rev-parse HEAD                    # exit 0 → 06954d11c2fb7a93b7ae57792d0df40d4e815ecf
git branch --show-current             # exit 0 → fix/pal-stdio-clink-audit-configs
git status --short                    # exit 0 (untracked paths only)
git remote -v                         # exit 0 → DDD-Enterprises/dopemux-mvp
```

## Directory creation

```bash
mkdir -p audit_inputs/pcp_dcp_full_architecture_regeneration/{ADJUDICATION_OUTPUTS,PR_925,PR_931,PCP_ARTIFACTS,DCP_EXTENSION_INPUTS,DNH_EXTENSION_INPUTS,REPO_AUTHORITY_DOCS,GOVERNANCE_CONTRACTS,OPENCLAW_ROUTING_INPUTS,CURRENT_GITHUB_STATE}
# exit 0
```

## PR #925 GitHub capture

```bash
gh pr view 925 --json number,state,isDraft,mergedAt,mergeable,headRefName,headRefOid,baseRefName,baseRefOid,updatedAt,url,title,body,changedFiles,additions,deletions,commits
# exit 0 (note: `merged` field unsupported; used mergedAt)

gh pr diff 925 --patch > PR_925/DIFF_FULL.patch     # exit 0
gh pr diff 925 --name-only > PR_925/CHANGED_FILES.txt # exit 0

gh pr checks 925 --json ...                          # exit 1 (unsupported fields)
gh pr view 925 --json statusCheckRollup > PR_925/CHECKS.json  # exit 0

gh api graphql ... -F number=925 > PR_925/REVIEW_THREADS_AND_REVIEWS.json  # exit 0
```

## PR #931 GitHub capture

```bash
gh pr view 931 --json ...                            # exit 0
gh pr diff 931 --patch > PR_931/DIFF_FULL.patch     # exit 0
gh pr diff 931 --name-only > PR_931/CHANGED_FILES.txt # exit 0
gh pr view 931 --json statusCheckRollup > PR_931/CHECKS.json  # exit 0
gh api graphql ... -F number=931 > PR_931/REVIEW_THREADS_AND_REVIEWS.json  # exit 0
```

## Evidence copy

```bash
cp -R audit_inputs/pcp_pr925_supervisor_adjudication/* ADJUDICATION_OUTPUTS/
cp -R audit_inputs/pcp_pr925_supervisor_adjudication/files/* PCP_ARTIFACTS/
cp -R audit_inputs/pcp_pr925_supervisor_adjudication/schemas PCP_ARTIFACTS/
cp -R audit_inputs/pcp_pr925_supervisor_adjudication/fixtures PCP_ARTIFACTS/
# + selective cp for DCP_EXTENSION_INPUTS, REPO_AUTHORITY_DOCS, GOVERNANCE_CONTRACTS, etc.
# exit 0 — 313 files total in bundle
```

## Secret scan

```bash
rg -n --hidden --no-ignore-vcs "OPENAI_API_KEY|..." audit_inputs/pcp_dcp_full_architecture_regeneration > SECRET_SCAN_REPORT.md
# exit 0 — 630 lines; all documentation/placeholder hits (see report header)
```

## Validation

```bash
python -m json.tool MANIFEST.json >/dev/null        # exit 0
find ... -name "*.json" | xargs python -m json.tool # exit 0 (all valid)
git diff --check                                     # exit 0
```

## Zip (post-clearance)

```bash
(cd audit_inputs && zip -r pcp_dcp_full_architecture_regeneration.zip pcp_dcp_full_architecture_regeneration)
# exit 0
```