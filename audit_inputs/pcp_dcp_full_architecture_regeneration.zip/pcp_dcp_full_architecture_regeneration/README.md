# PCP/DCP Full Architecture Regeneration Input Pack

## Purpose

- Read-only evidence pack for GPT-5.5 Pro
- Architecture target: PCP Core parent + DCP/dNh extensions
- Not implementation
- Not merge request

## Bundle ID

`TP-DMX-PCP-DCP-FULL-ARCH-INPUTS-0001`

## Assembly context

- Assembled from repo checkout `06954d11c2fb7a93b7ae57792d0df40d4e815ecf` on branch `fix/pal-stdio-clink-audit-configs`
- Live GitHub PR state captured 2026-06-19 (PR #925 OPEN draft; PR #931 CLOSED)
- PCP artifacts on current branch are absent; sourced from prior supervisor adjudication pack and live PR #925 diff

## Directory map

| Directory | Contents |
|-----------|----------|
| `ADJUDICATION_OUTPUTS/` | Prior PR #925 supervisor adjudication pack, DCP open-PR ledger |
| `PR_925/` | Live GitHub state, diff, reviews, checks for PR #925 |
| `PR_931/` | Live GitHub state, diff, reviews, checks for PR #931 |
| `PCP_ARTIFACTS/` | Schemas, fixtures, proof, validation reports from PR #925 branch |
| `DCP_EXTENSION_INPUTS/` | DCP docs, schemas, runtime surfaces, routing config |
| `DNH_EXTENSION_INPUTS/` | dNh fixture packs and supervisor doc (no live dNh repo) |
| `REPO_AUTHORITY_DOCS/` | AGENTS.md, architecture, PM plane, system boundaries |
| `GOVERNANCE_CONTRACTS/` | Dopetask spec, proof contracts, task packet templates |
| `OPENCLAW_ROUTING_INPUTS/` | Model routing policy + DCP openclaw-routing docs |
| `CURRENT_GITHUB_STATE/` | Recent PR sample from `gh pr list` |

## Important caveats

- PR #925 may be draft / not merge-ready (`NEEDS_SUPERVISOR`, `isDraft: true`)
- PR #931 is **CLOSED** (not merged); contracts exist only on that PR branch / merged PR #926 lineage
- Runtime exporter behavior is unproven (fixture-only validation)
- PCP extension contract schema is missing
- PCP authority-map schema is missing
- `PCP_ARTIFACTS/proof/PROOF.json` copy may lag PR head `68b8fd17` by repair commit; use `PR_925/DIFF_FULL.patch` for head freshness

## Start here for Pro

1. `INPUT_SUMMARY_FOR_PRO.md` — executive brief
2. `EVIDENCE_LEDGER.md` — what was included and why
3. `MISSING_OR_UNKNOWN.md` — gaps and blockers
4. `MANIFEST.json` + `CHECKSUMS.sha256` — machine inventory

## Forbidden actions during assembly

No runtime code edits, no PR mutation, no Dopetask, no Task Orchestrator MCP writes, no dNh runtime access, no live exporters.