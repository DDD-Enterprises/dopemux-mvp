## Summary

Adds the OpenClaw/DCP multi-model routing policy contracts as proposed, contracts-only artifacts under `contracts/openclaw-dcp-routing/`.

Also adds focused validation tests for JSON/YAML parsing, schema loadability, example route-decision validation, fail-closed UNKNOWN handling, PR Steward READY blockers, and OpenRouter profile controls. Includes the narrow markdown-location-guard exception for `contracts/openclaw-dcp-routing/**/*.md` so contract Markdown remains in the contracts tree without creating a docs mirror.

## Scope

- Contracts only; no runtime routing behavior enabled.
- No provider config or API integration changed.
- No OpenClaw integration code changed.
- No benchmark harness execution added.

## Validation

- `python -m pytest tests/test_markdown_location_guard.py tests/contracts/test_openclaw_dcp_routing_contracts.py -q` -> `52 passed`
- `git diff --check` -> exit 0
- `pre-commit run --files $(git diff --name-only)` -> exit 0 before commit
- Embedded audit reattempt via AGY / Claude Sonnet 4.6 Thinking -> `auditor_verdict: PASS`

## Remaining Gate Notes

Draft PR because PR Steward readiness still needs to be run on the created PR head and local benchmark certification is explicitly still required before any production/high-trust use.
