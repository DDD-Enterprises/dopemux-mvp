# Missing or Unknown Evidence

| Expected input | Status | Why it matters | Blocks Pro synthesis? |
|----------------|--------|----------------|----------------------|
| Opus PCP Core architecture adjudication (standalone) | MISSING | Full Opus verdict on PCP Core boundary cut | Partial — PR #925 AUDITOR_REPORT is adversarial audit only |
| GPT-5.5 Pro PCP architecture adjudication | MISSING | Pro-layer architecture verdict | Partial — this pack is input for that run |
| Opus + Pro reconciliation result | MISSING | Resolved conflicts between models | Yes for acceptance posture |
| Prior full PCP/DCP architecture regeneration prompt | MISSING | Continuity from prior Pro runs | No — can proceed fresh |
| Prior PR #925 supervisor adjudication prompt | CAPTURED | `ADJUDICATION_OUTPUTS/SUPERVISOR_INTAKE_SUMMARY.md` | No |
| generic PCP exporter runtime | MISSING | Proves negative-case execution | Yes for live-write gates |
| PCP extension contract schema | MISSING | Defines core vs extension boundary | Yes for clean architecture split |
| PCP authority-map schema | MISSING | Machine ownership enforcement | Partial — markdown matrix exists |
| dNh live exporter | MISSING | Live CRM adapter validation | No for architecture synthesis |
| DCP extension manifest | MISSING | Declares Dopemux extension surfaces | Partial — inferred from DCP docs/runtime |
| dNh extension manifest | MISSING | Declares dNh adapter contract | Partial — fixtures only |
| current PR #925 proof freshness | STALE RISK | `PCP_ARTIFACTS/proof/PROOF.json` after_sha=`84149bced`; PR head=`68b8fd17` | Partial — use `PR_925/DIFF_FULL.patch` |
| current PR #931 unresolved review threads | RESOLVED (mostly) | DCP routing contract blockers | No — PR closed; threads resolved |
| PR #931 merged state | CLOSED NOT MERGED | Contracts may exist via PR #926 | Partial — inspect PR #926 lineage |
| `contracts/openclaw-dcp-routing/` on current branch | MISSING | OpenClaw routing contracts | Partial — in PR_931 patch |
| `schemas/project_control_plane/` on current branch | MISSING | PCP schemas only on PR #925 | No — copied to PCP_ARTIFACTS |
| `RULES.md`, `SYSTEM_BOUNDARIES.md` (root) | MISSING | Root authority docs | Partial — equivalents under docs/03-reference |
| `PAL_*.md` governance files | MISSING | PAL doctrine standalone files | Partial — covered by AGENTS.md |
| External/vendor PCP reference docs | MISSING | Industry baseline comparison | No |
| dNh runtime repo (`/Users/hue/code/dNh_CRM`) | NOT ACCESSED | Live CRM truth | Intentionally excluded |

## Placeholder adjudication files

The following were not found as standalone artifacts and are tracked here instead of `ADJUDICATION_OUTPUTS/`:

- `OPUS_PCP_CORE_ARCHITECTURE_ADJUDICATION.md` — **UNKNOWN** (closest: `PCP_ARTIFACTS/.../AUDITOR_REPORT.md`, adversarial not architectural)
- `GPT55_PRO_PCP_ARCHITECTURE_ADJUDICATION.md` — **UNKNOWN** (this bundle is input for that run)
- `OPUS_PRO_RECONCILIATION.md` — **UNKNOWN**
- `FULL_PCP_DCP_ARCHITECTURE_REGENERATION_PROMPT.md` — **UNKNOWN**