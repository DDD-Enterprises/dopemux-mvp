# Git State at Assembly

## Checkout identity

| Field | Value |
|-------|-------|
| Repo | `DDD-Enterprises/dopemux-mvp` |
| Remote | `https://github.com/DDD-Enterprises/dopemux-mvp.git` |
| Branch | `fix/pal-stdio-clink-audit-configs` |
| HEAD | `06954d11c2fb7a93b7ae57792d0df40d4e815ecf` |
| Assembly date | 2026-06-19 |

## PR heads captured (live GitHub)

| PR | State | Draft | Head SHA | Base SHA | Mergeable |
|----|-------|-------|----------|----------|-----------|
| #925 | OPEN | true | `68b8fd1751d4ef12271dbfcdf0f271944aa6e9bf` | `a05ebf77578c3e163f90d2e194efd2441cebeac6` | MERGEABLE |
| #931 | CLOSED | false | `017dc52bd9163fb20514bdf295777f8fa435f833` | `697a6a20dfe36e6763049913a17f2415321e5932` | MERGEABLE |

## Working tree at assembly (primary checkout)

Untracked paths present (not copied into bundle):

- `.grok/`, `.workpack/`, `audit_inputs/dcp_pre_prompt6/`, `audit_inputs/dcp_queue_replan/`, `audit_inputs/open_pr_merge_train/`, `audit_inputs/pcp_pr925_supervisor_adjudication/`, `backups/`, assorted `claudedocs/`, `proof/TP-DMX-CLAUDE-AUTO-VALIDATION-001/`

This bundle directory `audit_inputs/pcp_dcp_full_architecture_regeneration/` was created during assembly.

## PCP artifacts branch note

PCP schemas, fixtures, and proof are **not** on current checkout HEAD. They exist on PR #925 branch `codex/tp-dmx-pcp-architecture-validation-0001` and were copied from prior adjudication pack + live PR diff.