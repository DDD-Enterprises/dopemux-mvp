---
id: INDEX
title: Index
type: explanation
owner: '@hu3mann'
author: '@hu3mann'
date: '2026-02-12'
last_review: '2026-03-22'
next_review: '2026-06-20'
prelude: Index (explanation) for dopemux documentation and developer workflows.
---
📑 Dopemux Task Packet Index
Canonical Registry · Execution History · Change Traceability
════════════════════════════════════════════════════════════
🎯 Purpose
This index is the authoritative registry of all Task Packets in Dopemux.
It exists to provide:
Traceability from design → execution
Visibility into active and completed work
A deterministic audit trail of system evolution
If a change cannot be traced to a Task Packet listed here, it is considered out of process.
────────────────────────────────────────────────────────────
🧭 How to Use This Index
Active packets indicate work in progress
Completed packets represent executed and audited changes
Superseded packets are preserved for history but must not be reused
This file should be updated whenever:
A new Task Packet is created
A packet changes status
A packet is superseded by another packet
────────────────────────────────────────────────────────────
🟡 Active Task Packets

| Packet ID | Subsystem | Title | Status | Related ADR |
| --- | --- | --- | --- | --- |
| TP-SIA-EXEC-0001 | Workflow Plane | Packet Execution Domain Models + Lease Store | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0002 | Workflow Plane | Packet Manifest V2 + Sidecar Contract | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0003 | Workflow Plane | Explicit Routing Slots + Cost Policy | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0004 | Workflow Plane | Supervisor Service + Canonical Commit Flow | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0005 | Workflow Plane | Implementer Runner Adapter Contract | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0006 | Workflow Plane | Auditor Runner + Proof Bundle Manifest | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0007 | Workflow Plane | Manual Handoff + Operator Resume Semantics | Ready | SIA Packet Execution ADR |
| TP-SIA-EXEC-0008 | Workflow Plane | Replay Repro Suite + Projection Hardening | Ready | SIA Packet Execution ADR |
| TP-DMX-PROOF-SCHEMA-LOCAL-VALIDATION-001 | Governance / CI | Local Proof Schema Validation Before Push | Active | N/A |
| TP-DMX-AIG-001 | Adaptive Ingress Plane | Service Census + Ingress Map + First Safe Slice | Ready | ADR — Adopt a Dopemux Adaptive Ingress Plane with Local Runtime Shims |
| TP-DMX-REPOHYG-001 | Repo Hygiene | Branch and worktree audit with deterministic cleanup plan | Ready | N/A |
| TP-DMX-REPOHYG-002 | Repo Hygiene | Execute phase2 safe archive cleanup | Ready | N/A |
| TP-DMX-REPOHYG-003 | Repo Hygiene | Resolve blocked and ambiguous cleanup survivors | Ready | N/A |
| TP-DMX-REPOHYG-004 | Repo Hygiene | Lost-work audit, stash preservation, and conservative cleanup | Ready | N/A |
| TP-DMX-REPOHYG-005 | Repo Hygiene | Remaining work disposition audit and cleanup-safe local pruning | Ready | N/A |
| TP-DMX-REPOHYG-006 | Repo Hygiene | Deep remaining work audit and recovery queue classification | Ready | N/A |
| TP-DMX-REPOHYG-007 | Repo Hygiene | Recover CLI/system audit hardening tranche from PR #554 | Ready | N/A |
| TP-DMX-REPOHYG-008 | Repo Hygiene | Remove Genetic Agent and Taskmaster active surfaces | Ready | N/A |
| TP-DMX-RTEAUDIT-001 | Repo Truth Extractor | Assemble pre-live audit pack for GPT-5.4 Pro | Ready | N/A |
| TP-DMX-RTE-55PRO-AUDIT-ASSEMBLY-001 | Repo Truth Extractor | Assemble GPT-5.5 Pro multi-pass audit pack | Active | N/A |
| TP-DMX-RTEOPUS-AUDIT-DOCS-001 | Repo Truth Extractor | Add recovered Opus UI/UX Claude design audit bundle to docs/audit | Active | N/A |
| TP-DMX-RTEINT-001 | Repo Truth Extractor | Integrate current RTE branch deltas into staging audit branch | Ready | N/A |
| TP-DMX-RTECANON-001 | Repo Truth Extractor | Establish `dopemux rte` as the canonical operator entrypoint | Ready | N/A |
| TP-RTE-V3-CONSENT-004 | Repo Truth Extractor | Gate legacy v3 execution and fail closed on unknown pipeline versions | Active | N/A |
| TP-RTE-WALKER-006 | Repo Truth Extractor | Exclude generated artifacts and secret-bearing files from prescan walker input | Active | N/A |
| TP-RTE-GOLIVE-REMEDIATION-001 | Repo Truth Extractor | Harden go-live preflight truth-split, SP registry contract, and cost-cap gates | Active | N/A |
| TP-RTE-GOLIVE-REMEDIATION-002 | Repo Truth Extractor | Contain pre-live validator execution and require parsed GO verdicts | Active | N/A |
| TP-RTE-BATCH-005 | Repo Truth Extractor | Repair batch result extraction and strict batch request payload handling | Merged (PR #614) | N/A |
| TP-RTE-BATCH-E2E-006 | Repo Truth Extractor | Wire strict batch response_format through v5 request construction | Merged (PR #615) | N/A |
| TP-RTE-STRICT-ATTESTATION-007 | Repo Truth Extractor | Ground strict passthrough attestations in runtime evidence | Merged (PR #616) | N/A |
| TP-RTE-DOCS-CANON-008 | Repo Truth Extractor | Canonicalize RTE operator docs around `dopemux rte` | Active | N/A |
| TP-RTE-FINAL-AUDIT-GROK-NONE-REASONING-006 | Repo Truth Extractor | Preserve xAI Grok 4.3 reasoning_effort=none | Merged (PR #705) | proof/repo-truth-extractor/audit-2026-05-22/TP-RTE-FINAL-AUDIT-GROK-NONE-REASONING-006_PROOF.json |
| TP-RTE-COSTPROFILE-E3-CONTRACTS-001 | Repo Truth Extractor | Extend structured_output_contracts.py: service_tier passthrough, prompt_caching_directives helper, anthropic_tool_use schema variant | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-E4-FINISH-001 | Repo Truth Extractor | Finish llm_runtime wiring: meta-dict exposure of service_tier / cached_tokens; cell alias resolution at call_llm entry | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-E7-LADDERS-FAILOVER-001 | Repo Truth Extractor | Rewrite 11 hardcoded ladder constants to cell-aliased lookups; add per-request failover + --disable-provider kill-switch | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-E8-YAML-V3-001 | Repo Truth Extractor | Restructure model_map.yaml to v3 (lane_defaults + tag_definitions + impact_class + 6 per-step overrides) + migration script | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-E9-TESTS-001 | Repo Truth Extractor | Integration coverage for cost-profile end-to-end flow across all 4 profiles + Anthropic cache + batch discount | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-F-VERIFY-001 | Repo Truth Extractor | Series-final verification gate: full test run + promptset v3 audit + bounded-lane dry-run + pal/codereview + pal/precommit | NOT_VERIFIED_ACCEPTED_AS_EVIDENCE | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-F-VERIFY-TOPOLOGY-REPAIR-001 | Repo Truth Extractor | Rehome F-VERIFY-001 proof/ledger evidence from polluted PR #698 onto a main-targeted replacement PR | Active | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-F-FULLSUITE-REPAIR-001 | Repo Truth Extractor | Repair CostProfile F full-suite failures accepted as evidence by F-VERIFY-001 | Merged (PR #709) | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-F-VERIFY-002 | Repo Truth Extractor | Series-gate verification after F-FULLSUITE-REPAIR (#709) and INDEX correction (#710): full RTE suite + bounded print-config + OpenRouter route-readiness + CLI import probes | Merged (PR #712) | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-OUTPUT-VALIDATORS-001 | Repo Truth Extractor | Post-step output validators (control_plane_truth_check + security_claim_verification) for structural / security_sensitive impact_class | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-RTE-COSTPROFILE-XAI-BATCH-VERIFY-001 | Repo Truth Extractor | Live probe to determine xAI /v1/batches support; updates spend_ledger + batch_clients + cost profile based on verdict | Ready | docs/90-adr/rte-cost-profiles-and-optimizer-wiring.md |
| TP-DMX-AGENTS-CODEX-ENDTOEND-0001 | Agent Guidance | Make Codex execute TP lifecycle end-to-end by default | Ready | N/A |
| TP-DMX-ORCH-DOCS-003 | Task Orchestrator | Document read-only/operator-status integration authority boundaries | Active | N/A |
| TP-DMX-COMPOSE-RESTORE-001 | Infra | Restore canonical Docker Compose authority | Ready | N/A |
| TP-CI-FULL-TEST-SUITE-001 | CI | Gate full RTE and auditor-router test suites | Active | N/A |
| TP-UI-DASHBOARD-BUILD-001 | UI Dashboard | Restore ui-dashboard npm install and build | Active | N/A |
| TP-BETA-MCP-02-COMPOSE-HEALTHCHECKS | Infra | Gate core MCP compose dependencies on healthchecked services | Active | N/A |
| TP-BETA-MCP-03-ADHD-REDIS-ISOLATION | ADHD Engine | Isolate ADHD Engine Redis keys by instance | Active | N/A |
| TP-DMX-GPTR-MCP-CONTAINER-UPDATE-001 | Infra / MCP | Restore GPT Researcher MCP container entrypoint and update package pin | Active | N/A |
| TP-SEC-COMPOSE-LITELLM-LOCALHOST-001 | Security | Externalize LiteLLM healthcheck key and localize compose service ports | Active | N/A |
| TP-SEC-WEAK-DEFAULT-SECRETS-001 | Security | Reject weak default secrets in env template and installer | Active | N/A |
| TP-DMX-ADHD-SIGNAL-E2E-WIRING-001 | ADHD Engine / Dashboard | Prove synthetic ADHD state updates reach the dashboard UI band | Active | N/A |
| TP-DMX-ADHD-SECRET-DEFAULTS-001 | ADHD Engine / Security | Remove remaining ADHD/WMA weak default secrets and fail closed outside dev/test/local | Active | N/A |
| TP-DMX-ADHD-PRIVACY-PAYLOADS-001 | ADHD Engine / Activity Capture | Enforce content-free ADHD activity payloads | Active | N/A |
| TP-DOCS-FIRST-TOUCH-PRODUCT-NAME-001 | Docs | Refresh active Start Here onboarding and product naming | Active | N/A |
| DMX-COCKPIT-STATIC-002 | UI Cockpit | Expose deterministic static cockpit renderer through guarded CLI wrapper | Merged (PR #528) | N/A |
| TP-DMX-COCKPIT-MERGE-STACK-CONSOLIDATE-001 | UI Cockpit | Audit and prepare Cockpit PR stack 568-571 plus PR 573 evidence for safe consolidation | Active | N/A |
| TP-DMX-COCKPIT-COMMAND-PALETTE-001 | UI Cockpit | Reconcile Command Palette broker primitive onto current main | Active | N/A |
| TP-DMX-COCKPIT-RUNTIME-RENDER-001 | UI Cockpit | Wire runtime renderer primitives to accepted Cockpit IA package contract | Active | N/A |
| TP-DMX-COCKPIT-SAFE-ACTIONS-001 | UI Cockpit | Materialize Safe Action Gate primitive contract packet metadata | Active | N/A |
| TP-DMX-COCKPIT-SETTINGS-RUNTIME-001 | UI Cockpit | Wire Settings/Admin/Runtime primitive surface to runtime renderer | Active | N/A |
| TP-DMX-COCKPIT-UNKNOWN-DRIFT-001 | UI Cockpit | Wire Unknown / Drift Queue primitive surface to runtime renderer | Active | N/A |
| TP-DMX-COCKPIT-INVENTORY-REGEN-001 | UI Cockpit | Regenerate current-head Cockpit command/surface inventory artifacts | Active | N/A |
| TP-DMX-COCKPIT-RUNTIME-CONTRACT-FIDELITY-001 | UI Cockpit | Repair Cockpit runtime contract-fidelity gaps | Active | N/A |
| TP-DMX-COCKPIT-DESIGN-PICKUP-001 | UI Cockpit | Create current-state Cockpit design pickup brief after pack-to-main consolidation | Active | N/A |
| TP-DMX-MOBILE-TUI-SPEC-001 | UI Cockpit | Install mobile-first tmux Cockpit UX specification without runtime changes | Active | N/A |
| PACKET_031 | Memory | Dual Capture Adapters, Single Ledger | Executing | ADR-213 |
| PACKET_032 | Memory | Chronicle Promotion Guards | Pending Audit | ADR-214 |
| DMX-COCKPIT-PMIMPL-PACK-001 | Cockpit / PM Plane | PM/Implementer cockpit processing pack | Ready | N/A |
| TP-DMX-COCKPIT-MAIN-STATE-RECON-001 | UI Cockpit | Reconcile origin/main and open PR cockpit state vs the pack remediation stack | Executed | N/A |
| TP-DMX-COCKPIT-MERGE-EXECUTE-001 | UI Cockpit | Define Ledger-gated Cockpit pack merge execution procedure without authorizing runtime mutation | Blocked Preflight | N/A |
| TP-DMX-DEPENDABOT-UV-RESOLVER-001 | Dependencies / CI | Repair Dependabot uv security update resolver metadata | Active | N/A |
| TP-BETA-INSTALL-02-CLAUDE-REVIEW-001 | Installer | Apply Claude review cleanup to BETA-INSTALL-02 network repair | Active | N/A |
| TP-BETA-INSTALL-01-MCP-01-REVIEW-001 | MCP Config | Repair PR #737 review blockers for portable Task Orchestrator launch | Active | N/A |
| TP-BETA-CLI-01-DECISIONS-REVIEW-001 | CLI Decisions | Repair PR #740 review blockers for decisions CLI subcommands | Active | N/A |
| TP-DMX-ADHD-INTERACTIVE-PROMPTS-001 | ADHD UX | Wire interactive prompts into launch and profile flows | Active | N/A |
| TP-DMX-ORCH-AUDIT-FIX-001 | Task Orchestrator | Close DMX-ORCH integration audit gaps | Active | N/A |
| DMX-DCP-MODEL-ROUTING-MVP-0006 | DCP / Model Routing | Classifier provenance hardening for trust-lowering signals | Active | N/A |
| DMX-DCP-MODEL-ROUTING-MVP-0007 | DCP / Model Routing | Trusted input-provenance contract for execution eligibility | Active | N/A |
| TP-DCP-MCP-RO-0002 | DCP / MCP | Architecture Doc And Multi Project Contract | Active | N/A |
| TP-DCP-MCP-RO-0003 | DCP / MCP | Inspect Dopemux Init Registry Contract | Active | N/A |
| TP-DCP-MCP-RO-0004 | DCP / MCP | Facade Scaffold Registry Resolver Repo Proof Tools | Active | N/A |
| TP-DCP-MCP-RO-0005 | DCP / MCP | ConPort And Dope Memory Read Adapters | Active | N/A |
| TP-DCP-MCP-RO-0006 | DCP / MCP | Dope Context And Task Orchestrator Read Adapters | Active | N/A |
| TP-DCP-MCP-RO-0007 | DCP / MCP | Secure MCP Tunnel Integration Docs And Manual Validation | Active | N/A |
| TP-DCP-MCP-RO-0008 | DCP / MCP | Hardening Cross Project Isolation And PR Readiness | Active | N/A |
| DMX-DCP-PROMPT5-EXTRACT-RECON-001 | DCP / Prompt 5 | Extract Prompt 5 chat-history docs and reconcile PR/Task Orchestrator runway state | Active | N/A |

────────────────────────────────────────────────────────────
🟢 Completed Task Packets

| Packet ID | Subsystem | Title | Completion Date | Outcome |
| --- | --- | --- | --- | --- |
| TP-DMX-RTEAUDIT-110 | Repo Truth Extractor | Gemini deep PAL audit across UX, prompts, routing, and operator readiness | 2026-04-23 | Accepted (Conditional Go) |
| TP-PM-ARCH-04A | PM Plane | Canonical PMTask Model + Store (Unit-only) | 2026-03-22 | Accepted |
| TP- PM-ARCH-04B | PM Plane | Canonical pm.* Events + Adapters | 2026-03-22 | Accepted |
| PACKET_024 | Infra | MCP Health Surface Hardening | 2026-01-26 | Accepted |
| PACKET_021 | Memory | Deterministic Chronicle Schema | 2026-01-18 | Accepted |
| TP-DMX-AI-ROUTING-001 | Governance / AI Routing | Stage-based dev-workflow AI model routing policy, reference, how-to, and Copilot agent stage tagging | 2026-06-06 | Accepted (PR #837, commit b987da994) |
| TP-DMX-AI-ROUTING-002 | Governance / AI Routing | Proof bundle schema and proof contract cross-references to the stage routing policy | 2026-06-06 | Accepted (PR #837, commit b987da994) |

────────────────────────────────────────────────────────────
⚪ Superseded Task Packets

| Packet ID | Superseded By | Reason |
| --- | --- | --- |
| PACKET_017 | PACKET_021 | Incomplete determinism guarantees |

────────────────────────────────────────────────────────────
🧠 Index Maintenance Rules
Never delete historical packets
Never reuse packet IDs
Status changes must be explicit
Completed packets require an audit outcome
Superseded packets must reference the replacing packet
────────────────────────────────────────────────────────────
Final Rule
If it’s not indexed here, it didn’t happen.
