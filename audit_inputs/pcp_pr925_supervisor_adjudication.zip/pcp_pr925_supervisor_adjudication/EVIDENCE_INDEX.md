# Evidence Index — PR #925 PCP Supervisor Adjudication

## GitHub State

- `GITHUB_PR925_STATE.json` — live PR metadata (head `68b8fd17`, draft, OPEN, MERGEABLE)
- `CHECKS.json` — live CI checks (all observed checks pass)
- `REVIEW_THREADS.json` — 2 threads (both `isOutdated: true`, `isResolved: false`)
- `REVIEWS.json` — 1 Codex review (`COMMENTED`, commit `6f151ca9ff`)
- `REVIEW_THREADS_AND_REVIEWS.json` — raw GraphQL bundle
- `PR925_DIFF.patch` — full PR diff (3237 lines)
- `PR925_DIFF_STAT.txt` — diff stat (32 files, +3040)
- `CHANGED_FILES.txt` — 32 changed paths

## Local Intake State

- `GIT_STATE.md` — intake worktree branch/HEAD/status
- `COMMAND_LOG.md` — commands, exit codes, deviations
- `README.md` — bundle overview

## PR Artifacts (`files/`)

Sourced from PR head ref `origin/pr-925-head` unless noted.

- `files/proof/TP-DMX-PCP-ARCHITECTURE-VALIDATION-0001/PROOF.json`
- `files/reports/project-control-plane/validation/ARCHITECTURE_VALIDATION_REPORT.md` *(alias: `docs/05-audit-reports/project-control-plane/architecture-validation-report.md`)*
- `files/reports/project-control-plane/validation/E2E_DRY_RUN_RESULT.json`
- `files/reports/project-control-plane/validation/AUDITOR_REPORT.md` *(alias: `proof/TP-DMX-PCP-ARCHITECTURE-VALIDATION-0001/AUDITOR_REPORT.md`)*
- `files/reports/project-control-plane/fixtures/dnh_crm_fixture/project_profile.json`
- `files/reports/project-control-plane/fixtures/dnh_crm_fixture/red_lanes.json`
- `files/reports/project-control-plane/fixtures/dopemux_fixture/project_profile.json`
- `files/reports/project-control-plane/fixtures/minimal_fixture/project_profile.json`

## Schemas

- `schemas/*.schema.json` — 11 PCP contract schemas from PR

## Fixtures (text/json only)

- `fixtures/dnh_crm_fixture/*` — evidence_export, negative_cases, project_profile, red_lanes
- `fixtures/dopemux_fixture/*` — evidence_export, negative_cases, project_profile, red_lanes
- `fixtures/minimal_fixture/*` — evidence_export, negative_cases, project_profile, red_lanes

## Governance Summaries

- `SUPERVISOR_INTAKE_SUMMARY.md` — adjudication question and expected outputs
- `UNKNOWN_AND_RISK_LEDGER.md` — unresolved evidence and decision hinge
- `MANIFEST.json` — SHA256 manifest of entire bundle
- `MANIFEST_COPY_STAGE.json` — copy-stage provenance and path-alias notes