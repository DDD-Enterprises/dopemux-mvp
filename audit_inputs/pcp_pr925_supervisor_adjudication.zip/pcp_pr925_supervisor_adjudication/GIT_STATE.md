# Git State

## git status --short
 M compose.yml
?? .grok/
?? .workpack/
?? audit_inputs/dcp_pre_prompt6/
?? audit_inputs/open_pr_merge_train/
?? audit_inputs/pcp_pr925_supervisor_adjudication/
?? backups/
?? claudedocs/dcp-routing-0005-lane-engine-design-2026-06-16.md
?? claudedocs/plan-claude-code-automation-2026-06-16.md
?? claudedocs/pr873-red-lane-triage-2026-06-16.md
?? claudedocs/spec-claude-code-automation-design-2026-06-16.md
?? proof/TP-DMX-CLAUDE-AUTO-VALIDATION-001/
?? scripts/mcp-wrappers/task-orchestrator-logback-debug.xml
?? task-packets/load-plan-claude-automation.json

## branch
fix/task-orchestrator-startup-reliability

## HEAD
cd5c11421202080e87c39e55ea0ff54b9307e1ee

## PR head ref (fetched for artifact sourcing)
68b8fd1751d4ef12271dbfcdf0f271944aa6e9bf

## Recent log
cd5c11421 Merge remote-tracking branch 'origin/fix/task-orchestrator-startup-reliability' into fix/task-orchestrator-startup-reliability
40cf2b9c1 fix(orchestrator): HTTP singleton recreates pre-fix MCP_PORT containers
073e0c2c7 Merge branch 'main' into fix/task-orchestrator-startup-reliability
559d7e2fa 🎨 Palette: Team Dashboard UX & Accessibility Enhancement (#932)
def5a5618 Merge branch 'main' into fix/task-orchestrator-startup-reliability
fdd060cd5 fix(orchestrator): stdio launcher defers to running HTTP singleton
c45b2c8e7 feat(conport): add migration foundation gate (#917)
9573ed979 fix(conport): grant schema to dopemux_age + TP-101 proof (#899)
6e46a4f69 fix(orchestrator): fail-soft when stdio launcher can't derive workspace
4c497e6db fix(orchestrator): use MCP_HTTP_PORT/MCP_HTTP_HOST for HTTP singleton
697a6a20d chore(deps): bump the npm_and_yarn group across 2 directories with 2 updates (#930)
9be961c8d fix(cockpit-design-system): resolve 6 case-collision pairs (DMX-COCKPIT-FONTS-104) (#922)
82d0392b6 DMX-COCKPIT-FONTS-103: full @font-face matrix + family-token reconcile (#918)
7bdeb4696 DMX-COCKPIT-FONTS-102: Editor proportional Nerd glyphs + stable family name (#914)
9f74d2abf DMX-COCKPIT-FONTS-101: rename plan keys + harden build/patch scripts (#912)
ea78e912f [codex] add gpt55 evidence intake bundle (#873)
707f76785 feat(dcp): DMX-DCP-TOOLING 101+102 foundation bundle (#885)
66d7e9074 chore(deps): bump the npm_and_yarn group across 2 directories with 1 update (#877)
9160ff1a9 proof(cockpit): reconcile command palette proof shape (#896)
83efd5737 style(start): DMX-START Wave 3 UI theming (3C-4/3C-5) — routing_cli, splash, brand_lint (#911)
