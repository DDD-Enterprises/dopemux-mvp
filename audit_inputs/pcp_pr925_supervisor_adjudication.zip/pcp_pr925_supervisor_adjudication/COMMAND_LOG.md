# Command Log — TP-DMX-PCP-925-SUPERVISOR-INPUTS-0001

Captured during bundle assembly on intake worktree `fix/task-orchestrator-startup-reliability`.

## Preflight

| Command | Exit | Notes |
|---------|------|-------|
| `git status --short` | 0 | Unrelated dirty: `M compose.yml`; untracked dirs present. Bundle-only writes under `audit_inputs/pcp_pr925_supervisor_adjudication/`. |
| `git branch --show-current` | 0 | `fix/task-orchestrator-startup-reliability` |
| `git rev-parse HEAD` | 0 | `cd5c11421202080e87c39e55ea0ff54b9307e1ee` |
| `git remote -v` | 0 | `origin` → `https://github.com/DDD-Enterprises/dopemux-mvp.git` |

## GitHub Fetch

| Command | Exit | Notes |
|---------|------|-------|
| `gh pr view 925 --json number,state,isDraft,merged,...` | 1 | **Deviation:** `merged` is not a valid `gh` JSON field. |
| `gh pr view 925 --json number,state,isDraft,mergedAt,mergeable,headRefName,headRefOid,baseRefName,baseRefOid,updatedAt,url,title,body,changedFiles,additions,deletions,commits` | 0 | Saved to `/tmp/pr925-view.json` → `GITHUB_PR925_STATE.json` |
| `gh pr diff 925 --stat` | 1 | **Deviation:** `--stat` flag unsupported by this `gh` version. |
| `git diff --stat a05ebf7..68b8fd17` | 0 | Used instead for `PR925_DIFF_STAT.txt` (32 files, +3040). |
| `gh pr diff 925` | 0 | 3237 lines → `PR925_DIFF.patch` |
| `gh pr checks 925 --json name,state,conclusion,...` | 1 | **Deviation:** `conclusion` not a valid field. |
| `gh pr checks 925 --json name,state,bucket,startedAt,completedAt,link` | 0 | Saved to `CHECKS.json` |
| `gh api graphql ... reviewThreads/reviews ...` | 0 | 2 threads, 1 review → split to `REVIEW_THREADS.json` / `REVIEWS.json` |
| `gh pr diff 925 --name-only` | 0 | 32 paths → `CHANGED_FILES.txt` |

## PR Head Ref (artifact sourcing)

| Command | Exit | Notes |
|---------|------|-------|
| `git fetch origin pull/925/head:refs/remotes/origin/pr-925-head` | 0 | Fetched PR head for read-only `git show` extraction |
| `git rev-parse origin/pr-925-head` | 0 | `68b8fd1751d4ef12271dbfcdf0f271944aa6e9bf` (matches `headRefOid`) |

## Bundle Build

| Command | Exit | Notes |
|---------|------|-------|
| `rm -rf audit_inputs/pcp_pr925_supervisor_adjudication` | 0 | Prior bundle (if any) removed before rebuild |
| `mkdir -p audit_inputs/pcp_pr925_supervisor_adjudication/{files,github,schemas,fixtures}` | 0 | |
| Copy `/tmp/*` artifacts into bundle | 0 | See bundle root files |
| Python copy stage (local + PR head fallback) | 0 | 31 artifacts copied; 0 missing; see `MANIFEST_COPY_STAGE.json` |
| `find ... python -m json.tool` (all bundle JSON) | 0 | All JSON valid |
| `python` manifest generator | 0 | `MANIFEST.json` |
| `git diff --check` | 0 | No conflict markers in diff |
| `(cd audit_inputs && zip -r pcp_pr925_supervisor_adjudication.zip ...)` | 0 | Optional upload zip created |

## Forbidden Actions (not executed)

- No `gh pr merge`, `gh pr ready`, or review-thread resolution
- No Dopetask / Task Orchestrator MCP writes
- No dNh runtime validation
- No runtime service code edits
- No external provider API calls