# UNKNOWN and Risk Ledger — PR #925

## Known open governance posture

- PR body states read-only Opus audit returned `NEEDS_SUPERVISOR`.
- External adversarial addendum (commit `84149bced`) **confirms** `NEEDS_SUPERVISOR`.
- Supervisor acceptance remains pending.
- PR remains **draft** (`isDraft: true`) as of capture.
- Latest head `68b8fd17` includes repair commit `fix(pcp-925): repair proof after_sha + dNh fixture policy_ref path`.

## Review thread state (captured)

| Thread | Path | Resolved | Outdated | Blocker status |
|--------|------|----------|----------|----------------|
| PRRT_kwDOPyIw986KJns5 | `proof/.../PROOF.json` | false | **true** | Prior P2 `after_sha` orphan — **repaired** at head |
| PRRT_kwDOPyIw986KJns9 | `dnh_crm_fixture/project_profile.json` | false | **true** | Prior P2 `policy_ref` path — **repaired** at head |

Threads remain formally unresolved on GitHub but are marked outdated. Supervisor should treat concrete Codex blockers as **superseded by repair commit** unless re-validated.

## Open auditor findings (from PR body / AUDITOR_REPORT)

- **H1 [OPEN]** auditor independence — external read-only pass is audit of record.
- **AAA-A [MEDIUM]** declared 9-step PAL chain never externally run (`codereview`/`precommit` `NOT_RUN`).
- **AAA-B [LOW]** structured `architecture_verdict` still reads `ARCHITECTURE_CONFIRMED_WITH_CORRECTIONS` while prose scopes fixture-only.
- Multi-model consensus (gpt-5.5 / gemini-2.5-pro / gpt-5.4) converged bare `CONFIRMED` label exceeds executed evidence.

## Known caveats to preserve

- Fixture-only validation does **not** prove runtime exporter behavior.
- Negative cases are asserted by fixture/dry-run evidence; no executable harness observed.
- No dNh runtime validation was run in this packet.
- No Dopetask execution was run.
- No Task Orchestrator MCP write was run.
- No live writes were performed by this packet.
- Green CI is **not** semantic proof of architecture acceptance.
- PR Steward / Codex review is **not** merge authority.

## Sourcing UNKNOWNs

- Required artifacts absent from intake worktree; sourced from PR head ref (read-only `git show`). Local runtime truth for PCP exporter remains unproven.
- Packet-listed `reports/.../AUDITOR_REPORT.md` and `ARCHITECTURE_VALIDATION_REPORT.md` paths do not exist on PR; satisfied via documented aliases (see `MANIFEST_COPY_STAGE.json`).

## Decision hinge

Whether `ARCHITECTURE_CONFIRMED_WITH_CORRECTIONS` is acceptable only as a planning/contracts/fixture-direction verdict, or overclaims because no exporter behavior exists.