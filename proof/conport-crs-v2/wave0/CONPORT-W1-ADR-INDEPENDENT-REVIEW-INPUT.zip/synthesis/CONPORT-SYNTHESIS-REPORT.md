# ConPort Target Model Synthesis Report

**Synthesis date:** 2026-07-21  
**Primary verdict:** `CONPORT_ADR_CHANGE_SET_READY_FOR_INDEPENDENT_REVIEW`  
**Research candidate verdict:** `CONPORT_ADR_CHANGE_REQUIRED_BEFORE_SYNTHESIS`  
**Implementation authorized:** **No**

## 1. Executive disposition

The repaired research candidate is strong enough to support architecture synthesis but not implementation. Its decisive finding is not that ConPort merely needs tidying. It is that the currently evidenced deployment behaves as a shadow-twin, multi-surface, shared-store system without trustworthy project, workspace, and instance authority.

The target selected here is **Dopemux ConPort Canonical Record Service v2**, a newly normalized Dopemux custom runtime with one canonical PostgreSQL record plane and one deterministic policy engine. Upstream `context-portal-mcp` remains a pinned design and compatibility reference, not a second runtime. AGE, Qdrant, Redis, dope-memory mirrors, dope-context indexes, graph views, and broker outputs are derived or separately governed planes. None may silently become canonical.

This synthesis therefore produces a documentation-only ADR packet as the first safe wave. Every code, schema, migration, runtime, client, cleanup, or cutover packet remains blocked until an independent reviewer accepts the exact ADR change set.

## 2. Evidence posture

The status vocabulary used throughout the artifacts is:

| Label | Meaning |
|---|---|
| `OBSERVED` | Directly supported by the candidate or re-opened current public source. |
| `INFERRED` | The most defensible conclusion from observations, with uncertainty retained. |
| `DECIDED` | A target architecture decision proposed by this synthesis. |
| `PROPOSED` | A policy, threshold, path, pin, or default requiring later ADR or operator acceptance. |
| `UNKNOWN` | Not established by the available evidence and not silently filled in. |

### 2.1 Input custody

`PASS`:

- The input ZIP is 29,108 bytes with SHA-256 `40972f2d5db05b7ca436ea55998d902ef18be3219e7ea68832668c85b8ad39be`.
- The sidecar matches the ZIP.
- CRC checks pass.
- Paths are safe and relative.
- No symlink, duplicate normalized path, or path traversal exists.
- The archive contains exactly the six required research artifacts.
- No package manifest is present. This is recorded as `NOT_PRESENT_ALLOWED_BY_FILESET_CLAUSE`, not treated as a failure.
- Every internal artifact byte count and SHA-256 was independently checked.

### 2.2 Public-source freshness

`OBSERVED`: the current Dopemux default-branch identity remained `5a9f8f7b5d4a03be323723a92baf3c4e162d5b65` during synthesis. The current upstream Context Portal default-branch identity remained `18bde469feb03c233d11c9a4941bd27bd859a5ff`. The latest stable upstream package observed was `context-portal-mcp 0.3.13`.

`OBSERVED`: every public repository path materially affecting the target was re-opened, including the ConPort source surfaces, server entrypoints, schema, migration gate, client configuration, repository identity marker, system boundaries, architecture references, and relevant ADRs.

`OBSERVED`: the candidate's local runtime evidence cannot be refreshed from this environment. It is therefore used according to its collection timestamp, without pretending to re-probe Hue's Docker runtime.

### 2.3 Candidate integrity caveat

`OBSERVED`: `CONPORT-DR-REPORT.md` contains a literal `{VERDICT}` placeholder near its final disposition even though `CONPORT-DR-DISPOSITION.json` carries the unambiguous primary verdict `CONPORT_ADR_CHANGE_REQUIRED_BEFORE_SYNTHESIS`. This is a source-artifact defect. It does not override the machine-readable disposition, but it should be repaired in any future research publication.

## 3. Findings that control the target

1. `OBSERVED`: two healthy ConPort-like containers shared one PostgreSQL authority plane. Their inspected custom application files were byte-identical, but their image and compose origins differed. No evidence-based rule made either container canonical.
2. `OBSERVED`: the shared store contained identities for Dopemux, adOps, `_system`, packet scopes, aliases, and pytest temporary paths. Fourteen of fifteen progress records belonged to adOps. Most progress and both workspace-context rows lacked instance provenance.
3. `OBSERVED`: port 3004 exposed a 13-tool JSON-RPC compatibility surface but did not behave as an MCP lifecycle endpoint. Port 3005 and initialized stdio remained unproven. Port 4004 was dark or unusable in the collected run.
4. `OBSERVED`: an unpinned `uvx --from context-portal-mcp` path created a separate upstream stdio surface inside the custom image. It was not a reproducible target identity.
5. `OBSERVED`: PostgreSQL was the proven custom runtime store. SQLite was present in one container but had no proven live custom-runtime I/O. AGE, Qdrant, Redis, event, and mirror configuration existed, but active graph/vector/mirror behavior was not proven.
6. `INFERRED`: current field presence and caller-supplied workspace values do not constitute authority enforcement. Stable identity, registry-backed authorization, RLS, negative tests, and deterministic policy are required.
7. `DECIDED`: the target is one logical canonical service with one policy engine. Multiple processes are acceptable only as intentional stateless replicas behind one routing authority after byte, configuration, policy, and behavior equivalence is proven.

## 4. Architecture selection

### Selected option

**Normalized Dopemux custom runtime**

The strongest bounded path is to normalize the custom PostgreSQL-based capability set rather than substitute the upstream SQLite package directly or keep parallel products under the same name.

Reasons:

- It preserves the richer structured record and integration direction already present in Dopemux.
- It permits a stable project/workspace/instance authority model that upstream does not provide by itself.
- It avoids treating per-workspace SQLite as a magic isolation amulet. SQLite can give physical file separation, but it does not establish actor, client, commit, worktree, packet, lifecycle, or cross-plane authority.
- It permits a single normalized contract for Claude Code, Codex, DCP, and internal services.
- It allows AGE, FTS, vector, Redis, and mirrors to be rebuilt from one canonical record plane.

The rejection is equally important: this is **not** a license to bless the current custom server. The target runtime, release, image, lock, schema bundle, and entrypoints do not yet exist. They must be built, pinned, tested, and accepted after the ADR gate.

## 5. Mandatory challenge adjudication

| Challenge | Disposition |
|---|---|
| Should ConPort remain canonical for progress? | **No, not broadly.** ConPort is canonical only for typed `progress_observation` and `work_evidence` records. Task Orchestrator owns status, transition legality, blockers, queue, completion authority, and next action. |
| Is the custom PostgreSQL/AGE story runtime truth? | **PostgreSQL is runtime truth; AGE authority is architectural residue until proven.** Canonical typed relationship assertions may live in PostgreSQL, but AGE topology is a derived projection. |
| Is the deployed tool surface sufficient? | **No.** Thirteen compatibility tools do not satisfy stable identity, approval, idempotency, lifecycle, quarantine, deterministic export/import, or admin separation. |
| Should SSE remain? | **No.** Use authenticated internal MCP Streamable HTTP or a Unix socket plus a thin stdio launcher. SSE adds a third semantic surface without demonstrated benefit. |
| Is unpinned `uvx --from context-portal-mcp` acceptable? | **No.** It violates reproducibility and creates an independently moving surface. Remove it from the target or pin it only as an isolated reference fixture. |
| Are dual agent/admin surfaces justified? | **Yes, but not dual policy engines.** Agent and admin audiences need different exposure. Both must route through the same policy engine; admin tools remain separate and unavailable to agents. |
| Do scratch notes belong in canonical storage? | **No by default.** Raw scratch is local/session state. Explicit reviewed promotion may convert selected content into a typed canonical record. |
| Can vector search be enabled before update/delete consistency passes? | **No.** It also needs privacy, provenance, tenant-isolation, deterministic tie-break, replay, and tombstone tests. |
| Should dope-memory mirroring fail open? | **Transport may be asynchronous after commit, but the event may not disappear.** Canonical write plus outbox is atomic. Consumer outage queues and retries; a failed outbox insert fails the write transaction. |
| Should Nauro-like mechanics be adopted? | **Adopt the mechanics, not a dependency.** Require pre-proposal conflict checks, explicit human approval, immutable supersession, deterministic human-readable export, and advisory retrieval. Improve the model by enforcing approval server-side and making supersession atomic. |
| Is a shared multi-workspace database defensible? | **Conditionally.** Only with stable IDs, scoped credentials/session variables, RLS, per-query scope defense, cross-scope negative tests, projection isolation, audit, and no ambiguous aliases. The current database fails this standard. |
| Would per-workspace SQLite solve isolation? | **Only partially.** It relocates operational burden and does not solve project/instance/actor/commit authority, DCP access, replicas, backups, or cross-plane references. |
| Centralized or per-workspace services? | **Centralized logical service fits the client mix better.** It gives Claude Code, Codex, DCP, and internal services one contract and policy engine. Physical replica or partition choices remain subordinate to tested isolation. |

## 6. Target authority summary

- **ConPort CRS v2:** decisions, durable structured product/project context, active-context revisions, typed relationships, custom structured records, progress observations/work evidence, audit and provenance.
- **Task Orchestrator:** workflow state, transition legality, blockers, queue, completion authority, next action.
- **Leantime:** passive PM metadata.
- **dope-memory:** append-only chronicle and mirror receipts.
- **dope-context:** advisory retrieval and ranking.
- **Serena/source:** technical and code facts at a commit.
- **dopecon-bridge:** adapter, router, translator, event ingress; never authority.
- **DCP:** redacted read-only facade.
- **AGE, Qdrant, Redis, FTS:** derived projections or transport.
- **Future brokers:** provenance-preserving orchestration only.

## 7. Identity decision

`project_id`, `workspace_id`, and `instance_id` are authority boundaries, not labels.

- `project_id`: registry-issued stable UUID. The recommended deterministic creation rule is UUIDv5 under an immutable operator-owned registry namespace, using an immutable project registry key rather than a path or mutable name.
- `workspace_id`: registry-issued durable UUID for a canonical logical data partition under a project. A simple repository may have one default workspace; a monorepo may declare several.
- `instance_id`: trusted registry-issued UUID, preferably time-sortable UUIDv7, for a temporary worktree, branch, task packet, supervised run, or agent session.

Every canonical read and write requires project, workspace, instance, actor, client, and request identity. Writes additionally require idempotency, commit, branch, trusted worktree reference, issue time, and registry generation. Paths are aliases and evidence only. Wrong project, workspace, or instance fails closed.

## 8. ADR impact

The controlling accepted ConPort authority ADR is too broad and operationally unsafe under current evidence. It must be superseded by a proposed target ADR. Multiple accepted integration and memory ADRs require bounded amendments, especially around progress semantics, identity, event durability, DCP routing, SSE, configuration pinning, projections, and lossy event behavior.

The repository ADR index also disagrees with file-authoritative status for multiple ADRs. Wave 0 repairs that governance drift as documentation only.

The exact register and patch text are in:

- `CONPORT-ADR-CHANGE-REGISTER.json`
- `CONPORT-ADR-CHANGE-SET.md`

## 9. Verification state

The synthesis artifacts and input custody pass their static gates. The current baseline fails source/runtime canonical identity, schema compatibility, project/workspace/instance isolation, broad progress authority, and security. Every target runtime, migration, client, projection, backup, performance, and rollback test remains `NOT_RUN`.

That distinction is deliberate. A specification can pass static review while the system it proposes remains nowhere near production acceptance.

## 10. Safe next action

The first safe packet is `CONPORT-W0-ADR-DOCS`. It may change only the exact ADR paths and Wave 0 proof path listed in `CONPORT-IMPLEMENTATION-SERIES.json`.

Wave 1 must be an independent acceptance or rejection review. Wave 2 and later packets are blocked until Wave 1 records explicit acceptance for the exact ADR digests and a separate authorized task packet activates implementation.

## 11. Final statement

No repository edit, code change, database mutation, migration, credential use, branch, commit, pull request, package publication, deployment, runtime change, container action, or cleanup occurred during this synthesis.
