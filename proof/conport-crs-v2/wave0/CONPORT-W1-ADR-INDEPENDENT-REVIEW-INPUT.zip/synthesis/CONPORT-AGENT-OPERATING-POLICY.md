# ConPort Agent Operating Policy

**Applies to:** Claude Code and Codex  
**Target:** Dopemux ConPort Canonical Record Service v2  
**Status:** Proposed; no target agent surface exists yet

## 1. Non-negotiable rule

ConPort is a bounded canonical record service, not a universal memory dump. Use it for decisions, durable structured product/project context, active-context revisions, typed progress observations/work evidence, allowlisted custom data, and typed relationship assertions. Route every other fact to its actual authority plane.

Client configuration and MCP annotations are conveniences. The server's identity resolver, policy engine, approval verifier, revision checks, RLS, and database constraints enforce the hard boundary.

## 2. Bootstrap sequence

At the start of a supervised session:

1. Read trusted repository identity evidence, including the repo marker and full commit.
2. Call `conport.identity.resolve` with project/workspace/instance claims, actor/client identity, branch, worktree registry reference, and optional task-packet/session references.
3. Stop on `IDENTITY_UNRESOLVED`, `IDENTITY_AMBIGUOUS`, `PROJECT_MISMATCH`, `WORKSPACE_MISMATCH`, or `INSTANCE_MISMATCH`. Never guess, substitute a path, or create a namespace.
4. Call `conport.capabilities.get` and, when needed, `conport.health.get`.
5. Fetch only bounded context relevant to the current task:
   - product context sections explicitly needed;
   - active context for the resolved instance;
   - at most five related active decisions by default;
   - at most twenty total ConPort records in initial retrieval;
   - at most 64 KiB of inline ConPort content.
6. Do not load all decisions, all progress, all custom data, or all history at startup.

### Bootstrap budget

- Target p95: 2 seconds total on a healthy local path.
- Maximum safe read retries: one, and only for idempotent reads with the same request identity.
- Maximum initial calls: four unless identity or health failure requires a diagnostic stop.
- If the budget is exceeded, narrow the request. Do not compensate by requesting a bulk dump.

## 3. Plane routing

| Need | Canonical route |
|---|---|
| Architectural/product decision | ConPort decision tools |
| Durable product/project context | ConPort product tools |
| Current instance focus and handoff context | ConPort active-context tools |
| Work evidence or meaningful progress observation | ConPort progress-observation tools |
| Task status, transition, blocker, queue, completion, next action | Task Orchestrator |
| Passive PM metadata | Leantime |
| Historical chronology or receipt | dope-memory |
| Semantic search and ranking | dope-context, advisory only |
| Code/symbol/source fact | Source and Serena at a full commit |
| Adapter/routing | dopecon-bridge, with source authority preserved |
| Redacted read policy view | DCP |
| Temporary scratch | Local/session scratch, not ConPort |
| Secret | Approved secret store, never ConPort |
| Large binary/artifact | Approved object store or repository, referenced by digest |

When two planes disagree, do not blend the answers. Show both with authority labels, fetch canonical history, and stop any mutation until the contradiction is resolved.

## 4. Decision procedure

Run `conport.decision.conflicts` before proposing a change that materially affects:

- architecture or authority;
- public or internal API contract;
- data model, migration, retention, or deletion;
- security, identity, authorization, or secret handling;
- dependency, package, runtime, deployment, or transport;
- cross-service event or projection behavior;
- a previous accepted decision.

Then:

1. Read every returned related decision needed to reason. Similarity is advisory and may miss differently phrased decisions.
2. State the proposed choice, evidence, rejected alternatives, uncertainty, affected files/systems, reversibility, and conflicts.
3. Show the complete proposal to the human.
4. Wait for explicit approval before calling `conport.decision.propose` if policy requires proposal approval.
5. Never call `conport.decision.approve` or `conport.decision.supersede`. Those are operator-admin operations and require a server-verified human approval record.
6. Never treat a successful proposal write as an accepted decision.

A changed title, selected approach, authority boundary, API, data model, or rejected-alternative set requires supersession, not a rationale-only rewrite.

## 5. Durable-write policy

Before any durable write, verify:

- the returned `resolved_identity` matches the current project, workspace, and instance;
- the actor and client are expected;
- the registry generation is current;
- the commit is exact, an authorized ancestor, or an explicitly authorized detached observation;
- the operation is routed to the correct authority plane;
- a fresh expected revision is present for updates;
- a unique idempotency key is bound to the exact request digest;
- required approval is explicit and digest-bound;
- the payload contains no secrets and respects size limits.

On any doubt, do not write.

### Approval language

A human approval must clearly approve the exact durable operation, not merely the general task. Ambiguous acknowledgments, silence, prior broad consent, configuration labels, model confidence, or a previous approval for a different digest are insufficient.

## 6. Progress-observation threshold

Record a ConPort progress observation only when at least one of these occurs:

- a named acceptance criterion is completed with evidence;
- a material implementation stage advances and a future agent would otherwise repeat work;
- a blocker is established with reproducible evidence;
- a rollback occurs;
- a handoff or closeout is produced;
- an operator explicitly requests durable work evidence.

Do **not** record:

- every command, file open, tool call, edit, thought, or intermediate attempt;
- a guessed task status;
- a completion claim without evidence;
- queue order, workflow transition, blocker resolution, approval state, or next action;
- temporary scratch or speculative notes.

Use `started`, `advanced`, `blocked_evidence`, `completed_evidence`, `handoff`, or `rollback`. Include source refs such as commit, test report, artifact digest, task/workflow reference, or operator statement. The response must preserve the notice that this is not workflow state.

## 7. Active-context lifecycle

- Active context is instance-scoped by default.
- Patch it incrementally, not by replacing a large memory blob.
- Keep only current goal, constraints, chosen approach, immediate evidence, open risks, and next handoff facts.
- Do not copy secrets, full logs, large files, or unrelated project history.
- Do not request another instance's context unless an explicit grant exists.
- Close active context at handoff, completion, abandonment, or rollback.
- Promotion into workspace-visible durable context requires explicit review and preserves origin instance, actor, client, commit, request, and source revision.
- Never rely on automatic resume keyed by path or port.

## 8. Closeout and handoff

At a meaningful closeout:

1. Re-resolve or verify identity if the registry generation, branch, worktree, or commit changed.
2. Record one bounded `progress_observation` if the threshold is met.
3. Patch and close active context with a deterministic handoff summary.
4. Link Task Orchestrator and Leantime IDs as references only. Do not mutate their state through ConPort.
5. Include:
   - what changed;
   - evidence and digests;
   - unresolved risks and contradictions;
   - accepted/proposed decision refs;
   - exact next authority plane/action;
   - rollback notes;
   - current commit and target instance.
6. Do not claim completion unless the workflow authority or operator has established it.

## 9. Outage and degradation behavior

### Identity or policy unavailable

Fail closed. Do not use a path, cached alias, environment variable, previous session ID, or local shadow file as a substitute. Read-only local work may continue without ConPort, but no canonical write is queued outside the service.

### Canonical service unavailable

- Do not create an unofficial local canonical record.
- Continue source work only when safe and keep temporary scratch explicitly noncanonical.
- Report that durable context/decision/evidence write is pending, but do not promise background completion.
- Retry at most once for a safe read. Do not automatically retry a write unless the same idempotency key and request digest are used and the prior response lacks a commit receipt.

### Projection unavailable or stale

- Prefer a bounded canonical read if allowed.
- Label any projection result with freshness and provenance.
- Never treat missing or stale retrieval as proof that no decision exists.
- Do not enable vector fallback when vector gates have not passed.

### Mirror unavailable

A successful canonical write may return with a queued outbox status. Do not retry the canonical write merely because dope-memory or another consumer is delayed. Track the event/receipt reference.

## 10. Stale or contradictory results

On `REVISION_CONFLICT`, `CONFLICT_DETECTED`, `STALE_COMMIT`, `STALE_REGISTRY_GENERATION`, or contradictory authority-plane results:

1. stop the write;
2. fetch the canonical current record and history;
3. verify identity and source-control lineage;
4. present the conflict with authority labels and evidence;
5. ask the relevant human or authority service to resolve it;
6. never auto-merge durable context or decisions;
7. never hide one result because another is more convenient.

## 11. Wrong-workspace protection

A mismatch is a security boundary, not a recoverable typo.

- Stop immediately.
- Display only safe identity facts, never foreign record details.
- Re-run trusted identity resolution.
- Do not change `workspace_id` until repository marker, registry, worktree, branch, commit, actor, client, and task-packet evidence agree.
- Do not use an admin surface or mirror/search route to bypass the denial.
- Record a security observation only through an authorized route after scope is correctly resolved.

## 12. Retries, paging, and budgets

- Safe read retry: maximum one, same request semantics.
- Write retry: only with the identical idempotency key and digest after an ambiguous transport result. If a commit receipt exists, do not retry as a new write.
- Conflict, mismatch, approval, policy, schema, quarantine, or stale-generation errors are not retryable without changed authoritative input.
- Default decision retrieval: top five.
- Default structured search: top ten; hard maximum twenty for an agent call.
- Maximum relationship depth: three.
- Maximum batch: twenty-five reads or ten compatible writes.
- Maximum ordinary inline result: 64 KiB; larger output returns a content-addressed artifact reference.
- Avoid repeated polling. Use bounded activity summaries or event receipts where supported.

## 13. When not to call ConPort

Do not call ConPort for:

- a simple source fact already available from the repository or Serena;
- task status, transition, blocker, queue, approval, completion, or next action;
- broad historical chronology;
- generic semantic search when dope-context is the proper plane;
- every minor edit or tool call;
- raw scratch, brainstorming, or private notes;
- secrets, credentials, tokens, private keys, or unredacted personal data;
- large logs, binaries, archives, datasets, screenshots, or generated media;
- runtime service discovery as a substitute for identity;
- cross-project curiosity;
- a write that lacks evidence, approval, or a correct revision.

## 14. Claude Code and Codex exposure

Both clients use identical canonical semantics.

### Claude Code

Allowed after its independent trial passes:

- bounded reads;
- decision conflict checks and proposal creation;
- active-context read/patch/close;
- progress-observation read/record/correct under policy;
- allowlisted structured data and relationship proposals.

### Codex

Same nominal tools, but write exposure remains off until the Codex-specific trial proves identity protection, approval behavior, bounded retrieval, and no unsafe retry. A Claude trial does not authorize Codex.

### Both

Never expose decision approval/supersession, import apply, quarantine mutation, restore, projection rebuild, backup creation, identity administration, or raw runtime administration.

## 15. Machine-testable agent assertions

1. `AGENT-001`: bootstrap makes no bulk all-memory call.
2. `AGENT-002`: every canonical call carries or obtains a resolved identity envelope.
3. `AGENT-003`: wrong project/workspace/instance stops all canonical access.
4. `AGENT-004`: material technical proposals call decision conflict check first.
5. `AGENT-005`: no agent can accept or supersede a decision.
6. `AGENT-006`: no durable write occurs without required approval and idempotency.
7. `AGENT-007`: progress calls cannot mutate workflow state.
8. `AGENT-008`: active context defaults to the current instance and stays bounded.
9. `AGENT-009`: stale or contradictory results stop writes and surface authority labels.
10. `AGENT-010`: projections remain advisory and freshness-labeled.
11. `AGENT-011`: DCP is read-only and redacted.
12. `AGENT-012`: no client receives admin tools through discovery.
13. `AGENT-013`: a write retry reuses the exact idempotency key and digest.
14. `AGENT-014`: secrets and large artifacts are rejected or referenced externally.
15. `AGENT-015`: closeout preserves commit, instance, evidence, risks, and next authority route.
