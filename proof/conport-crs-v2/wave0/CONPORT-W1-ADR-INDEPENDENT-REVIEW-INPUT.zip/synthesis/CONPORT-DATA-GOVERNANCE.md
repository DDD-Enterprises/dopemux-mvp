# ConPort Data Governance and Lifecycle

**Target:** Dopemux ConPort Canonical Record Service v2  
**Status:** Proposed pending ADR acceptance  
**Canonical database boundary:** `dopemux_conport.conport_v2`

## 1. Governance principles

1. Identity is an authority boundary.
2. Canonical state is typed, revisioned, provenance-bearing, and attributable.
3. A cache, index, graph, mirror, rollup, export, prompt injection, or adapter result is not canonical merely because it is useful.
4. Unknown provenance remains unknown or is quarantined. It is never invented.
5. Destructive lifecycle changes use supersession, tombstone, retention, and reviewed purge rather than silent mutation.
6. Test and fixture data are physically separated from production.
7. Human-readable portability is a first-class acceptance requirement.
8. Every policy below is subject to accepted ADR authority and later legal/privacy review.

## 2. Canonical schema

The target uses a dedicated PostgreSQL database or equivalent isolated boundary with schema `conport_v2`. The following logical tables are required; final names may change only through the accepted schema bundle.

| Logical table | Purpose | Key controls |
|---|---|---|
| `registry_projects` | Stable project identities | immutable project_id, aliases separate, lifecycle state |
| `registry_workspaces` | Durable canonical workspace identities | project FK, unique canonical key, no path authority |
| `registry_instances` | Temporary execution scopes and lineage | workspace FK, parent, purpose, commit/worktree refs, expiry |
| `registry_aliases` | Paths, names, remotes, markers, historical aliases | normalized value, type, evidence, collision state |
| `registry_grants` | Actor/client/instance visibility and operation grants | exact scope, expiry, revocation, approver |
| `records` | Stable canonical object identity and class | UUID, project/workspace, namespace, classification, current revision |
| `record_revisions` | Immutable content revisions | revision UUID, digest, actor/client/request, commit, origin identity |
| `decisions` | Decision lifecycle root | proposed/accepted/superseded, current accepted revision |
| `decision_approvals` | Human approval evidence | proposal digest, approver role, scope, expiry, single use |
| `progress_observations` | Typed work evidence | observation class, evidence refs, no workflow mutation |
| `active_contexts` | Instance-scoped lease-bound context | visibility, lease, review, close/handoff state |
| `custom_data` | Allowlisted typed structured records | namespace, schema ref, canonical key |
| `relationship_assertions` | Typed semantic assertions | source/target refs, relation type, evidence, lifecycle |
| `idempotency_keys` | Write replay protection | scope/client/tool/key unique, request digest, result receipt |
| `policy_decisions` | Deterministic allow/deny audit | rule bundle digest, inputs digest, decision, reasons |
| `audit_log` | Immutable security and lifecycle audit | actor/client/request, operation, scope, result, digest |
| `outbox_events` | Atomic canonical change event queue | sequence, payload digest, publish state, retry metadata |
| `consumer_receipts` | Mirror/projection consumer result | event/consumer unique, status, target digest, attempts |
| `quarantine_records` | Ambiguous or prohibited legacy/source records | source locator/digest, classification, reason, access restriction |
| `schema_migrations` | Target-specific operator-gated ledger | bundle digest, checksum, operator, status, epoch |
| `projection_checkpoints` | Derived consumer cursors | projection, source snapshot, event sequence, generation |
| `retention_holds` | Legal/operator holds | object scope, reason, authority, expiry/review |

The target does not use the legacy shared `public` schema as a shortcut. Canonical and projection roles are separated. Projection roles have no write permission to canonical tables.

## 3. Namespace taxonomy

Every record uses one allowlisted top-level namespace:

- `product`
- `decision`
- `progress_observation`
- `active_context`
- `pattern`
- `custom`
- `relationship`
- `registry`
- `quarantine`
- `projection`
- `event`
- `receipt`
- `test` only in physically isolated test environments

Custom subnamespaces require a registered schema, owner, sensitivity classification, retention class, and authority declaration. A free-form string cannot create a new production namespace.

## 4. ID policy

### Stable object IDs

- New canonical records: UUIDv7 or another accepted collision-resistant server-issued UUID.
- Deterministic registry IDs: UUIDv5 under an immutable operator-owned namespace from immutable registry keys.
- Revision IDs: UUIDv7, immutable.
- Human handles: optional, unique only within declared scope, never authority.
- External references: typed URI containing source authority, project/workspace, object class, ID, and optional revision.

### Event IDs

Recommended deterministic event ID input:

```text
namespace_uuid
project_id
workspace_id
aggregate_id
revision_id
operation
idempotency_key
schema_version
```

The exact canonicalization is versioned and covered by a golden-vector test. Event IDs are not derived from content alone because identical content in different scopes must not collide.

### Deduplication

- Writes deduplicate by scoped idempotency key plus canonical request digest.
- Same key and same digest returns the original receipt.
- Same key and different digest fails with `IDEMPOTENCY_CONFLICT`.
- Import deduplicates by source authority, source record ID, source revision/digest, and migration run.
- Similar text, embedding proximity, matching title, or matching path is not a deduplication rule.

## 5. Identity and provenance

Every canonical revision stores:

- project_id, workspace_id, instance_id;
- origin project/workspace/instance for promotion or migration;
- actor_id and authenticated subject;
- client_id and client version/pin;
- request_id and idempotency key;
- full commit SHA;
- branch ref and trusted worktree registry ref;
- optional task packet and session refs;
- registry generation;
- policy decision ID and policy bundle digest;
- expected prior revision;
- source authority references;
- content digest, schema version, creation time;
- review, expiry, sensitivity, and retention class.

A path may be stored as redacted alias evidence. It cannot replace stable identity. Absolute user paths should not be exported unless an operator-selected redaction profile permits them.

## 6. Authority-domain references

External objects are referenced, not copied as false authority.

A reference includes:

```json
{
  "authority": "task-orchestrator|leantime|dope-memory|source|serena|dcp|other-registered",
  "project_id": "uuid",
  "workspace_id": "uuid",
  "object_type": "typed-string",
  "object_id": "opaque-id",
  "revision_or_version": "optional",
  "source_uri": "safe-canonical-uri",
  "digest": "optional-sha256",
  "observed_at": "RFC3339"
}
```

ConPort does not copy Task Orchestrator status and then claim it as its own state. It stores a reference and, where useful, an observation about evidence.

## 7. Review, expiry, and active context

### Product/project context

- Durable but reviewable.
- Each material section has owner, last-reviewed time, next review, and status.
- Expired context remains historical but is labeled stale and cannot silently drive a durable write.
- Material changes use revision checks and approval according to policy.

### Active context

- Instance-scoped by default.
- Lease and review expiry required.
- Proposed default maximum open lease: 30 days, subject to operator policy.
- Close on completion, handoff, rollback, abandonment, or supersession.
- Closed context remains historical but is excluded from default active retrieval.
- Promotion selects explicit fields/revisions and preserves origin.

### Decisions

- Proposed decisions may expire or require revalidation if commit, architecture, or evidence materially changes.
- Accepted decisions remain authoritative until superseded or explicitly retired under an accepted ADR process.
- Retrieval returns status and supersession lineage.

## 8. Supersession and correction

- Immutable history is the default.
- A correction appends a new revision and points to the corrected revision.
- Material decision change creates a replacement decision and atomically marks the old decision superseded.
- Custom data material replacement appends a superseding revision.
- Relationship assertions are superseded or tombstoned, not silently overwritten.
- An active-context patch creates a new revision; close is a lifecycle revision.
- No ordinary client can delete history to make a conflict disappear.

## 9. Deletion, purge, and propagation

### Logical deletion

- Create a tombstone revision.
- Emit a canonical deletion event.
- Hide the object from ordinary current reads.
- Preserve audit and minimal provenance.
- Propagate tombstone to dope-memory receipt, dope-context, FTS, graph, vector, caches, and rollups.

### Hard purge

Hard purge is admin-only and requires:

- explicit legal/privacy or operator authority;
- no active retention hold;
- approved scope and object list;
- verified backup policy consistent with the purge obligation;
- independent review for bulk or sensitive purge;
- proof that derived systems processed the purge;
- a non-sensitive purge receipt where legally permissible.

A projection may be rebuilt or pruned without deleting canonical history.

## 10. Retention and archival

The following are **proposed defaults**, not accepted policy:

| Class | Proposed online retention | Archive/purge rule |
|---|---|---|
| Accepted decisions and supersession history | Indefinite | Archive only by accepted policy; no routine purge |
| Product/project context revisions | Indefinite while project active | Archive after project closure; preserve accepted decision refs |
| Active context | 30 days after close online | Archive thereafter; purge only under policy/hold review |
| Progress observations/work evidence | 2 years online | Archive after 2 years; retain evidence refs as policy requires |
| Audit and policy decisions | Minimum 2 years | Longer for security/legal needs |
| Idempotency keys | 90 days | Purge after safety window if no active dispute |
| Delivered outbox rows | 30 days after all required receipts | Archive summary/digest; retain failed/dead-letter rows until adjudicated |
| Consumer receipts | 1 year | Archive with source event digest |
| Quarantine | Until adjudicated plus verified backup | No ordinary expiry |
| Projection data | Operational only | Rebuildable; prune at any time consistent with lag/rebuild policy |
| Test data | Test-environment policy | Never migrate to production |

Retention holds override ordinary purge. Final values require privacy, legal, operational, and cost review.

## 11. Test and fixture separation

- Separate database or cluster boundary where practical.
- Separate schema, role, credentials, secrets, object-store prefix, event topic, and projection collection.
- Production registry rejects `/tmp`, pytest, fixture, test, fake, sandbox, and configured temporary path patterns unless an operator explicitly registers a nonproduction environment.
- Test project/workspace IDs come from a separate namespace and cannot collide with production UUIDv5 namespaces.
- Production imports reject test namespace records.
- Tests never use production credentials or projection collections.
- A fixture may resemble production data, but it carries synthetic classification and no copied secrets or personal data.

## 12. Deterministic export and import

### Export bundle

Recommended format:

```text
manifest.json
records.jsonl
revisions.jsonl
decisions.md
product-context.md
relationships.jsonl
events.jsonl or event-cursor.json
redaction-report.json
```

Rules:

- deterministic ordering by object class, stable ID, revision time, revision ID;
- canonical JSON key ordering, UTF-8, LF, no volatile timestamps except declared snapshot time;
- exact snapshot, schema, policy, redaction profile, and source digests in manifest;
- human-readable Markdown for decisions and product context;
- no secrets or disallowed path disclosure;
- content-addressed artifact reference and SHA-256;
- same data plus same profile produces byte-identical output.

### Import

- Validation is side-effect free.
- Every record maps to a classification and target identity.
- Unknown or conflicting identities are quarantined.
- Apply is operator-admin, digest-bound, idempotent, backup-gated, and audited.
- Import never overwrites accepted history in place.

## 13. FTS, vector, graph, and reindexing

All indexes are derived.

Required checkpoint fields:

- projection name and version;
- project/workspace partition;
- source snapshot revision;
- last event sequence and event ID;
- index generation and build digest;
- build time and freshness;
- failed/dead-letter event count;
- source schema and redaction profile.

Reindexing uses canonical snapshot plus ordered events. A rebuilt projection must produce the accepted visible result set and source digests. Update/delete consistency, tombstone propagation, and tenant isolation are mandatory. Vector additionally requires privacy and deterministic ordering acceptance.

## 14. Event and mirror governance

### `conport.record.changed.v1`

Required fields:

```json
{
  "event_id": "uuid",
  "event_type": "conport.record.changed.v1",
  "schema_version": "1.0.0",
  "sequence": 123,
  "occurred_at": "RFC3339",
  "aggregate_type": "decision|product_context|active_context|progress_observation|custom_data|relationship",
  "aggregate_id": "uuid",
  "revision_id": "uuid",
  "operation": "created|revised|accepted|superseded|closed|promoted|merged|tombstoned|restored",
  "identity": {"project_id": "uuid", "workspace_id": "uuid", "instance_id": "uuid"},
  "actor_id": "subject",
  "client_id": "client",
  "request_id": "uuid",
  "idempotency_key": "opaque",
  "commit_sha": "full-sha",
  "branch_ref": "opaque",
  "worktree_ref": "registry-ref",
  "task_packet_id": "optional",
  "policy_decision_id": "uuid",
  "canonical_uri": "conport://...",
  "payload_sha256": "sha256",
  "redacted_summary": "bounded",
  "sensitivity": "classification",
  "supersedes_revision_id": "optional-uuid",
  "tombstone": false
}
```

### Mirror receipt

```json
{
  "event_id": "uuid",
  "consumer_id": "registered-consumer",
  "consumer_version": "immutable-pin",
  "status": "accepted|duplicate|rejected|dead_lettered",
  "attempt_count": 1,
  "received_at": "RFC3339",
  "processed_at": "RFC3339",
  "source_payload_sha256": "sha256",
  "target_record_id": "optional",
  "target_payload_sha256": "optional",
  "identity_digest": "sha256",
  "error_code": "optional-typed-code"
}
```

Proposed retry default: exponential backoff with jitter, maximum 12 attempts over 24 hours, then dead letter and operator alert. This is a proposed operational default, not an accepted constant.

## 15. Backup, restore, and disaster recovery

Required before migration or cutover:

- encrypted full backup;
- point-in-time recovery capability where supported;
- database configuration, extensions, roles, RLS, schema bundle, policy bundle, and migration ledger captured by digest;
- content-addressed export independent of the database backup;
- isolated restore drill;
- record/revision/event/receipt count and digest reconciliation;
- documented RPO/RTO measured from the drill;
- secret material stored separately from artifacts;
- restore plan that names irreversible boundaries.

A backup that has not been restored is a hopeful archive, not proven recovery.

## 16. Large-artifact rule

Inline canonical payload limit proposal: 256 KiB per revision before compression. Larger or binary content is stored in an approved repository or object store and referenced by:

- content-addressed URI;
- SHA-256;
- byte count;
- media type;
- sensitivity and retention class;
- encryption/storage class where applicable;
- creating actor/client/request and source authority.

ConPort may store a redacted summary and structured metadata. It does not become a blob warehouse.

## 17. Contamination and quarantine

Legacy/source rows receive exactly one primary classification:

1. `CANONICAL_SAFE`: stable identity and provenance directly supported.
2. `ALIAS_RESOLVABLE`: identity supported after deterministic alias resolution.
3. `INSTANCE_SCOPED`: valid project/workspace but visible only in a supported instance.
4. `PACKET_SCOPED`: tied to a task packet; requires explicit lifecycle decision.
5. `FOREIGN_PROJECT`: belongs to another registered project and moves to that project's isolated migration or quarantine.
6. `SYSTEM`: service/system material requiring a separately authorized namespace.
7. `TEST_FIXTURE`: test/temp/fixture data, prohibited from production canonical import.
8. `AMBIGUOUS`: insufficient evidence; quarantine.

Quarantine preserves source location, source row ID, source digest, original fields, collection/export time, classification reason, classifier version, reviewer, and adjudication history. Ordinary agents and DCP cannot read quarantined payloads.

## 18. Migration and rollback governance

- No in-place mass relabeling.
- No automatic DDL.
- No dual canonical writes.
- No use of a later projection to invent earlier canonical provenance.
- No cleanup before accepted reconciliation and rollback window.
- Every migration run has source export digest, target bundle digest, mapping/classification manifest, import receipt, and backup receipt.
- Final delta requires legacy write stop.
- Rollback stops target writes before restoring the last accepted epoch.
- If a migration is irreversible, rollback is restore, not application downgrade.

## 19. Machine-checkable invariants

1. `DATA-001`: every production canonical record has non-null project_id and workspace_id.
2. `DATA-002`: every production canonical revision has non-null instance_id, actor_id, client_id, request_id, commit_sha, and policy_decision_id.
3. `DATA-003`: every current record points to one existing immutable revision.
4. `DATA-004`: every write idempotency key is unique in its declared scope.
5. `DATA-005`: same idempotency key plus different request digest is rejected.
6. `DATA-006`: aliases are stored separately from canonical IDs.
7. `DATA-007`: one normalized alias cannot map to multiple active identities.
8. `DATA-008`: production registries reject test/temporary namespaces.
9. `DATA-009`: RLS denies cross-project and cross-workspace access before result materialization.
10. `DATA-010`: active context is instance-scoped unless an explicit valid grant exists.
11. `DATA-011`: promotion retains origin project/workspace/instance and source revision.
12. `DATA-012`: decision acceptance has an unexpired matching approval record.
13. `DATA-013`: decision supersession is bidirectional and atomic.
14. `DATA-014`: progress observations have evidence refs and no workflow mutation field.
15. `DATA-015`: canonical write and outbox event commit or roll back together.
16. `DATA-016`: one consumer has at most one effective receipt per event ID.
17. `DATA-017`: projection checkpoints never exceed the last verified canonical event sequence.
18. `DATA-018`: tombstoned records are absent from ordinary current reads and propagated to required projections.
19. `DATA-019`: quarantined payloads are inaccessible to ordinary agent and DCP roles.
20. `DATA-020`: deterministic export of one snapshot/profile is byte-identical.
21. `DATA-021`: import validation performs no canonical mutation.
22. `DATA-022`: imported records retain source identity/digest and migration run.
23. `DATA-023`: large artifacts are content-addressed and not stored inline above the accepted limit.
24. `DATA-024`: secrets are rejected by schema/policy and absent from ordinary exports.
25. `DATA-025`: no hard purge executes under an active hold.
26. `DATA-026`: backup restore reconciliation matches accepted record, revision, event, and receipt digests.
27. `DATA-027`: projection roles cannot update canonical tables.
28. `DATA-028`: DCP role has no write privilege.
29. `DATA-029`: admin operations produce immutable audit events.
30. `DATA-030`: no Wave 2+ migration begins without accepted ADR and separate authorization.
