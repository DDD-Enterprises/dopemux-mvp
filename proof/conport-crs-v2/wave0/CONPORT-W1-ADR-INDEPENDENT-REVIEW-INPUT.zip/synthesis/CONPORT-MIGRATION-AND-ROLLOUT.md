# ConPort Migration and Rollout Plan

**Target:** Dopemux ConPort Canonical Record Service v2  
**Status:** Proposed and ADR-gated  
**Current implementation authorization:** None

## 1. Rollout doctrine

This is an incremental authority migration, not a container swap.

The current system combines shadow runtime identities, incompatible surfaces, a contaminated shared store, nullable instance provenance, broad progress semantics, dark integrations, and unpinned package launch. A big-bang rewrite would maximize exactly the risks the target is supposed to remove.

Rules:

- no Wave 2+ work before independent ADR acceptance and a separate authorized packet;
- no parallel work across identity, policy, schema, migration, or cutover boundaries;
- no dual canonical writes;
- no provenance invention;
- no destructive cleanup before an accepted rollback window;
- no projection or mirror promoted to authority;
- no target write route until isolation, backup, security, and rollback gates pass.

## 2. Rollout state machine

```text
RESEARCH_EVIDENCE_ACCEPTED_FOR_SYNTHESIS
  -> ADR_CHANGE_SET_PROPOSED
  -> ADR_INDEPENDENT_REVIEW
       -> REJECTED / CHANGES_REQUIRED
       -> ACCEPTED_BUT_IMPLEMENTATION_NOT_AUTHORIZED
  -> IMPLEMENTATION_PACKET_AUTHORIZED
  -> FROZEN_AND_INVENTORIED
  -> IDENTITY_POLICY_PROVEN
  -> ISOLATED_SCHEMA_PROVEN
  -> NORMALIZED_SERVICE_PROVEN
  -> DATA_CLASSIFIED_AND_SHADOWED
  -> ISOLATION_AND_AGENT_TRIALS_PROVEN
  -> EVENTS_PROJECTIONS_SECURITY_RECOVERY_PROVEN
  -> CUTOVER_AUTHORIZED
  -> TARGET_CANONICAL
  -> ROLLBACK_WINDOW_CLOSED
  -> LEGACY_DEPRECATED
```

No transition is implied by elapsed time. Every arrow requires named proof and authority.

## 3. Fifteen-step incremental rollout

### Step 1: Freeze and inventory

**Objective:** stop the authority plane from drifting while establishing fresh runtime truth.

Actions after authorization:

- announce and enforce a bounded legacy write freeze or read-only window;
- inventory full container IDs, image digests, process commands, ports, network bindings, compose origins, mounts, environment, healthchecks, package versions, source hashes, database target, schemas, roles, clients, wrappers, and cron/automation;
- capture a fresh tool-surface and protocol classification for every advertised endpoint;
- identify all globally bound or unauthenticated routes;
- record dark/dead surfaces without guessing.

Stop if the write freeze cannot be trusted or the fresh inventory materially contradicts the accepted ADR without adjudication.

### Step 2: Backup and export

**Objective:** prove recovery before touching authority.

- create an encrypted database backup and capture WAL/PITR position where supported;
- export legacy records deterministically with source table, row ID, raw identity fields, timestamps, digests, and schema metadata;
- capture roles, grants, extensions, migrations, configuration, package locks, and source/runtime pins;
- restore the backup into an isolated environment;
- reconcile row counts and digests;
- content-address the export and restore proof.

No backup gate passes merely because a file exists. The restore must work.

### Step 3: ADR change and independent acceptance

**Objective:** make architecture authority explicit before implementation.

- execute `CONPORT-W0-ADR-DOCS` on exact allowed documentation paths;
- independently execute `CONPORT-W1-ADR-INDEPENDENT-REVIEW`;
- record accepted/rejected/changes-required with exact ADR digests;
- if accepted, make effective status transitions without authorizing code;
- issue a separate authorized Wave 2 packet.

Rejection returns to documentation. It does not justify implementing the most convenient subset.

### Step 4: Version and image pinning

**Objective:** define one immutable target runtime identity.

Required target identity tuple:

```text
git_sha
lockfile_sha256
oci_image_digest
sbom_digest
configuration_sha256
policy_bundle_sha256
tool_contract_sha256
schema_bundle_sha256
migration_bundle_sha256
```

- remove floating `uvx --from context-portal-mcp` from the target plan;
- if upstream is retained as a comparison fixture, pin exact commit/package and isolate it from canonical storage and agent configs;
- do not declare a tag or container name canonical;
- record reproducible build proof.

### Step 5: Identity model

**Objective:** implement and prove stable project/workspace/instance authority before canonical data import.

- create trusted project, workspace, instance, alias, and grant registries;
- mint stable IDs under accepted namespace rules;
- implement alias normalization for path, symlink, case, remote, marker, branch/worktree, and packet evidence;
- implement collision denial and test/temp rejection;
- authenticate actor/client and enforce registry generation;
- verify commit/worktree lineage;
- implement explicit lifecycle create/fork/handoff/promote/merge/archive;
- prove no read creates state.

Do not proceed if any wrong-scope request returns data, even if the client later filters it.

### Step 6: Normalized adapter and service boundary

**Objective:** implement one canonical contract and policy engine without importing legacy data yet.

- implement MCP Streamable HTTP or Unix-socket core;
- implement thin stdio launcher;
- implement normalized request/response envelope, typed errors, revision checks, idempotency, approval verification, and result budgets;
- separate agent and admin discovery while sharing policy;
- implement DCP read-only adapter;
- keep direct database access prohibited;
- keep SSE out of the target;
- keep legacy compatibility aliases narrow and deprecating.

Target service initially uses isolated fixtures only.

### Step 7: Schema changes

**Objective:** establish the canonical isolated storage boundary.

- create dedicated database/schema and least-privilege roles;
- implement registry FKs, records/revisions, decisions/approvals, observations, active context, custom data, relationships, idempotency, audit, quarantine, outbox, receipts, migrations, and projection checkpoints;
- enable RLS and scoped transaction settings;
- add explicit query scope defense;
- create target migration bundle with checksums and operator gate;
- prove backup/restore against the target schema;
- prohibit hidden DDL and automatic production migration.

The legacy `public` schema remains source evidence, not the target.

### Step 8: Data classification and quarantine

**Objective:** decide what legacy data can enter authority.

For every source row, assign exactly one:

- `CANONICAL_SAFE`
- `ALIAS_RESOLVABLE`
- `INSTANCE_SCOPED`
- `PACKET_SCOPED`
- `FOREIGN_PROJECT`
- `SYSTEM`
- `TEST_FIXTURE`
- `AMBIGUOUS`

Specific handling:

- Dopemux rows with stable supporting evidence may import into the registered Dopemux workspace.
- adOps rows migrate only under the adOps project process or remain quarantined; they do not become Dopemux context.
- `_system` rows require a separately authorized system namespace.
- packet-scoped rows require an explicit packet lifecycle decision.
- pytest/temp paths are test fixtures and are blocked from production import.
- null instance provenance is not backfilled from a container default unless contemporaneous evidence proves it.
- aliases are mapped only through deterministic evidence.

Produce a human-reviewable classification manifest and quarantine report before import.

### Step 9: Multi-workspace and multi-instance isolation

**Objective:** prove shared service/database safety or abandon it.

Run the full matrix across every tool and route:

- wrong project, workspace, instance;
- alias/case/symlink/short-name collision;
- forged actor/client;
- stale registry generation;
- stale/unrelated commit;
- test namespace;
- cross-workspace search, counts, paging, export, batch, history, activity, graph, FTS, vector, mirror, admin;
- active-context visibility and expiry;
- handoff, promotion, merge, supersession, archive;
- replica equivalence if replicas are proposed.

Any cross-scope visibility fails the shared-hosting design. The contingency is stronger physical partitioning or per-workspace services, not weaker tests.

### Step 10: Agent policy

**Objective:** make client behavior bounded while keeping server enforcement primary.

- generate catalog and client configs from immutable accepted tool snapshot;
- expose only audience-appropriate tools;
- remove unpinned and shadow surfaces;
- run Claude Code behavioral trial;
- run Codex behavioral trial independently;
- run DCP read-only trial;
- verify bounded startup, conflict checks, approval, observation thresholds, closeout, retries, wrong-workspace stop, and no admin exposure;
- keep writes disabled per client until its own trial passes and cutover is separately authorized.

### Step 11: Event and mirror repair

**Objective:** guarantee durable cross-plane change evidence.

- publish `conport.record.changed.v1` from atomic outbox;
- implement consumer idempotency, receipts, bounded retry, dead letter, alerts, and replay;
- connect dope-memory as chronicle consumer while preserving its separate authority;
- distinguish lossy UI telemetry from durable canonical changes;
- prove outage, duplicate, out-of-order, replay, backlog, and receipt-digest behavior;
- monitor outbox oldest age, backlog count, attempts, DLQ, receipt mismatch, and contamination.

Canonical writes can fail only if their own transaction/outbox fails. Consumer outage after commit yields queued delivery, not data loss or duplicate write.

### Step 12: Retrieval and graph projections

**Objective:** rebuild useful query planes without moving authority.

- build native FTS projection only after create/update/supersede/delete/replay consistency passes;
- build dope-context and graph projections from a canonical snapshot plus ordered events;
- include scope, source record/revision, generation, cursor, freshness, and digest in every projection result;
- propagate tombstones and supersession;
- run full rebuild and compare visible result sets and digests;
- keep vector disabled until privacy, provenance, isolation, deterministic tie-break, update/delete, tombstone, replay, and rebuild gates all pass.

### Step 13: Observability

**Objective:** make authority failures visible before users discover them.

Required metrics and alerts:

- identity unresolved/ambiguous/mismatch counts;
- cross-project/workspace/instance denials;
- forged actor/client and stale commit denials;
- RLS denials and policy-decision outcomes;
- idempotency replay/conflict;
- revision and decision conflicts;
- approval failures;
- quarantined/contaminated record counts;
- outbox backlog and oldest age;
- consumer lag, retries, DLQ, receipt mismatch;
- projection generation, freshness, delete/supersession lag;
- tool latency, result truncation, rate limit;
- backup age, restore verification age;
- target/legacy route use during rollout.

Logs are structured, redacted, scope-safe, and linked to request/policy IDs.

### Step 14: Acceptance

**Objective:** run the exact acceptance matrix, not a vibes-based launch ritual.

- every required gate receives `PASS`, `FAIL`, or `NOT_RUN`;
- all cutover-required gates must be `PASS`;
- an unexecuted target test stays `NOT_RUN`;
- source/runtime identity is refreshed;
- security review and rollback rehearsal are independent;
- Claude, Codex, and DCP trials are separately recorded;
- any material drift returns the affected earlier gate to `NOT_RUN` or `FAIL`.

A static architecture pass does not compensate for a runtime isolation failure.

### Step 15: Deprecation and cleanup

**Objective:** remove ambiguity only after the target proves itself and rollback leverage is preserved.

Order:

1. authorize cutover;
2. stop legacy writes;
3. take final backup/export;
4. apply validated final delta;
5. set target epoch and one canonical write route;
6. progressively enable clients;
7. monitor and reconcile;
8. keep legacy read-only for the accepted rollback window;
9. independently review post-cutover evidence;
10. disable/remove shadow twins, unpinned uvx, stale configs, dark ports, and direct DB routes;
11. archive images/configs/exports needed for audit and rollback;
12. update ADR/index/runtime records.

Cleanup before this order is complete is not optimization. It is evidence destruction.

## 4. Legacy-to-target data map

| Legacy element | Target treatment |
|---|---|
| Raw string `workspace_id` | Resolve through registry/alias classification; never copy blindly |
| Nullable `instance_id` | Import only when supported; otherwise workspace-level historical record or quarantine according to class, with unknown retained |
| Broad `progress_entries` | Classify as progress observation/work evidence, foreign-project, workflow-like, test, or ambiguous; never infer Task Orchestrator state |
| `workspace_contexts` | Split into durable product context or instance-scoped active context only with evidence; otherwise quarantine |
| Decisions with legacy IDs | Preserve source ID as migration provenance; mint target stable ID and immutable revision |
| Custom data | Require allowlisted namespace and schema; unknown free-form data quarantined or externally archived |
| Relationship/AGE data | Import canonical typed assertions only when source and target refs are supported; rebuild AGE projection |
| Search cache/Qdrant/Redis | Discard as derived; rebuild after target gates |
| SQLite residue | Treat as a candidate source artifact only if live provenance is independently established; never merge by presence alone |
| `_system` data | Separate authorized system namespace or quarantine |
| adOps data | Separate registered project migration, not Dopemux import |
| pytest/temp data | Exclude from production; preserve only in test evidence if needed |
| Packet aliases | Require explicit packet reference and lifecycle classification |

## 5. Shadow-read strategy

After isolated import:

- keep legacy writes frozen;
- issue matched read cases against legacy export/adapters and target canonical service;
- compare identity resolution, record presence, revision history, decision status, observations, product context, custom data, relationships, and export;
- explain every difference as intentional normalization, quarantine, redaction, or defect;
- do not route user writes to both systems;
- treat target shadow results as noncanonical until cutover authority is issued.

## 6. Cutover criteria

Cutover requires all of the following:

- effective accepted ADR set and separate implementation/cutover authorization;
- immutable target identity tuple;
- successful isolated backup/restore;
- 100 percent source-row classification;
- reviewed quarantine manifest;
- passed identity, RLS, wrong-scope, lifecycle, decision, progress, active-context, event, projection, export/import, agent, performance, security, and rollback gates;
- no open critical/high security finding;
- no unexplained shadow-read difference;
- bounded outbox/projection lag;
- target client configs generated from accepted snapshot;
- final backup/export and validated delta plan;
- named operator and independent reviewers.

## 7. Rollback plan

### Trigger examples

- cross-project/workspace/instance leak;
- wrong-scope search or projection result;
- decision approval or supersession defect;
- unexpected record/digest mismatch;
- unbounded outbox or projection lag;
- mirror receipt corruption;
- security exposure;
- backup/restore uncertainty;
- client behavior violating approval or authority boundaries;
- performance collapse that threatens data integrity or isolation.

### Procedure

1. Stop target canonical writes at the trusted gateway.
2. Preserve target database, audit, idempotency, outbox, receipts, logs, and exact runtime digests for incident analysis.
3. Determine the last committed target event sequence and whether any final-delta records require reconciliation.
4. Restore or reactivate only the last accepted application/schema epoch according to the rehearsed plan.
5. If legacy write service must resume, do so only after reconciling target committed writes and preventing duplicate idempotency keys. Do not simply point clients back and hope.
6. Disable target client write routes; allow read-only forensic access only to authorized operators.
7. Rebuild or discard projections from the chosen canonical epoch.
8. Verify record, revision, decision, outbox, and receipt digests.
9. Issue incident and rollback records with authority labels.
10. Return failed gates to `FAIL` or `NOT_RUN` and require a new acceptance cycle.

An application downgrade is not a valid rollback after an irreversible schema or cleanup change. Restore is required.

## 8. Stop conditions applying to every step

Stop immediately when:

- ADR authority or implementation authorization is missing;
- source/runtime identity cannot be established;
- a path outside the packet allowlist changes;
- a secret appears in an artifact, log, export, or prompt;
- identity resolution is ambiguous;
- a cross-scope result appears;
- provenance would need to be guessed;
- a backup cannot be restored;
- an outbox event can be lost after commit;
- a projection cannot propagate deletion/supersession;
- admin exposure reaches an agent;
- an unpinned dependency or image enters the target;
- any required acceptance gate is `FAIL` or `NOT_RUN` at its decision boundary.

## 9. No-action statement

This plan changed no repository, runtime, container, database, schema, package, configuration, or data. It is a contingent rollout design only.
