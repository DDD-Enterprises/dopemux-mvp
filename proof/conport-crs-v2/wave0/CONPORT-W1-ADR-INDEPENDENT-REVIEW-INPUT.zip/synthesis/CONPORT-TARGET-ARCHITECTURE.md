# Dopemux ConPort Canonical Record Service v2

**Status:** Proposed, contingent on independent ADR acceptance  
**Design baseline:** Dopemux `5a9f8f7b5d4a03be323723a92baf3c4e162d5b65`  
**Upstream reference baseline:** Context Portal `18bde469feb03c233d11c9a4941bd27bd859a5ff`, `context-portal-mcp 0.3.13`  
**Implementation authorization:** None

## 1. Canonical identity

The term **ConPort** is overloaded in the current system. The target name is **Dopemux ConPort Canonical Record Service v2** (`ConPort CRS v2`). It is a new normalized Dopemux service, not the current twin-container deployment and not the unpinned upstream launcher.

| Required decision | Target |
|---|---|
| Source repository | `DDD-Enterprises/dopemux-mvp` |
| Design source baseline | `5a9f8f7b5d4a03be323723a92baf3c4e162d5b65` |
| Target release | `UNKNOWN_NOT_BUILT`; must be an immutable semver release after acceptance |
| Target git pin | `PROPOSED`; exact full SHA required before Wave 2 completion |
| Dependency lock pin | `PROPOSED`; exact lockfile SHA-256 required |
| OCI image pin | `PROPOSED`; exact content digest required, tags are insufficient |
| Configuration pin | `PROPOSED`; generated configuration SHA-256 required |
| Policy pin | `PROPOSED`; deterministic policy bundle SHA-256 required |
| Schema bundle pin | `PROPOSED`; migration bundle and schema SHA-256 required |
| Upstream role | Pinned source/protocol/tool reference and isolated comparison fixture only; never a parallel canonical runtime |
| Proposed service entrypoint | `dopemux conport serve` |
| Proposed thin agent launcher | `dopemux conport mcp-stdio` |
| Entrypoint existence | `UNKNOWN_NOT_IMPLEMENTED`; names are target contract, not a claim about current source |
| Canonical storage | Dedicated PostgreSQL database `dopemux_conport`, schema `conport_v2`, least-privilege roles, RLS, immutable revisions, transaction outbox |
| Native FTS | Optional derived index in PostgreSQL after update/delete/replay consistency passes |
| Vector | Disabled in canonical service; optional dope-context projection only after privacy, provenance, isolation, update/delete, replay, and deterministic ordering gates pass |
| Graph | Canonical typed relationship assertions in PostgreSQL; AGE graph is a rebuildable projection |
| Deployment | One logical service and one policy engine. Start with one canonical process. Stateless replicas are allowed only behind one trusted gateway after equivalence proof. |
| Agent transport | Thin local stdio launcher to authenticated MCP Streamable HTTP or Unix-domain-socket core |
| Internal transport | Authenticated MCP Streamable HTTP or bounded HTTP/event contracts on loopback/private network |
| SSE | Prohibited in target |
| Admin contract | Separate operator CLI or authenticated control API, not discoverable by agents |
| Update policy | Explicit, pinned, reviewed, tested, and reversible; no floating `uvx`, image tags, or implicit package upgrades |
| Rollback boundary | Last independently accepted application, configuration, policy, and schema epoch with verified backup and event cursor |
| Migration boundary | Explicit operator-gated bundle; no hidden DDL, no automatic production migration, no destructive cleanup before rollback window closes |

## 2. Logical topology

```text
Claude Code ---- local stdio launcher ----+
Codex ---------- local stdio launcher ----+--> trusted gateway / identity resolver
DCP ------------ read-only adapter -------+             |
Internal services -- authenticated route -+             v
                                                one policy engine
                                                     |
                                                     v
                                         ConPort CRS v2 service
                                                     |
                           +-------------------------+-----------------------+
                           |                         |                       |
                    PostgreSQL canonical       transaction outbox      audit/approval
                    records + revisions              |                   registries
                           |                         v
                           |             dopecon-bridge / consumers
                           |                 |            |
                           |                 v            v
                           |            dope-memory   dope-context
                           |             chronicle    retrieval index
                           |                              |
                           +------------------------------+--> AGE/FTS/vector projections
```

Every arrow into the canonical service crosses the same identity and policy engine. No client, bridge, facade, projection, or admin tool receives direct table authority.

## 3. Identity and authority model

### 3.1 Canonical IDs

#### `project_id`

- Format: UUID.
- Issuer: trusted project registry controlled by the operator authority.
- Recommended creation: UUIDv5 under an immutable registry namespace from an immutable project registry key.
- Forbidden sources of authority: absolute path, repository display name, container name, compose project, port, current working directory, or environment variable alone.
- Mutable aliases: repository remotes, `.repo_id` marker, display names, paths, historical names.

#### `workspace_id`

- Format: UUID.
- Issuer: trusted workspace registry.
- Meaning: durable canonical data partition beneath exactly one `project_id`.
- A simple project normally has one default workspace. A monorepo may register multiple explicit workspaces with non-overlapping authority rules.
- Paths and worktrees are aliases or execution evidence, never workspace IDs.

#### `instance_id`

- Format: trusted registry-issued UUID, preferably UUIDv7 for new instances.
- Meaning: temporary execution scope such as a worktree, branch, task packet, supervised run, or agent session.
- Instances have lineage, lifecycle state, owner/client grants, branch/worktree/commit evidence, creation and expiry timestamps.
- Instance creation, fork, handoff, promotion, merge, archive, and supersession are explicit operations. A read may never silently create or fork an instance.

### 3.2 Trusted resolution

Clients may supply claims, but claims do not become authority. A trusted gateway resolves them against authenticated actor/client identity, repository markers, registry state, grants, and source-control lineage.

Resolution order:

1. Authenticate actor and client.
2. Validate the registry generation.
3. Resolve immutable `project_id` and `workspace_id`.
4. Normalize aliases using realpath, symlink, case, remote, and marker evidence.
5. Reject any collision or disagreement.
6. Resolve `instance_id` and lifecycle state.
7. Verify commit, branch, trusted worktree reference, and optional task-packet lineage.
8. Compute exact scope and grants.
9. Emit an immutable policy decision and resolved identity envelope.

### 3.3 Mandatory request envelope

Every canonical read and write requires:

```json
{
  "project_id": "uuid",
  "workspace_id": "uuid",
  "instance_id": "uuid",
  "actor_id": "authenticated-subject",
  "client_id": "registered-client",
  "request_id": "uuid"
}
```

Every write additionally requires:

```json
{
  "idempotency_key": "opaque-unique-key",
  "commit_sha": "40-hex-full-sha",
  "branch_ref": "opaque-scm-ref",
  "worktree_ref": "trusted-registry-ref-not-path",
  "issued_at": "RFC3339",
  "registry_generation": 123,
  "task_packet_id": "optional-typed-ref",
  "session_id": "optional-authenticated-ref",
  "parent_instance_id": "optional-uuid"
}
```

Every result, including denial, returns the resolved or attempted identity envelope, alias evidence, applied grants, registry generation, commit relation, authenticated principal, and policy decision ID. Error responses must not leak foreign-scope record existence.

### 3.4 Path and alias normalization

- Resolve realpath and symlink chains under a trusted filesystem boundary.
- Apply platform-aware case rules.
- Compare canonical repository remotes and `.repo_id`-like markers.
- Treat worktree paths as instance evidence only.
- Reject temporary and test path patterns in production registries.
- A short name that maps to more than one project or workspace returns `IDENTITY_AMBIGUOUS`.
- No alias miss may create a new namespace during an ordinary read or write.

### 3.5 Shared database decision

One service may host multiple projects and workspaces only after all of these pass:

- stable registry IDs and foreign keys;
- least-privilege roles and scoped credentials;
- transaction-scoped project/workspace/instance settings;
- PostgreSQL RLS;
- explicit predicates in every application query as defense in depth;
- no cross-tenant FTS/vector/graph index leakage;
- wrong-scope tests for reads, writes, searches, counts, batches, exports, admin, mirrors, and projections;
- audit and alerting on denied cross-scope attempts.

This makes a shared database defensible in principle. The currently evidenced store is not defensible.

### 3.6 Multiple containers

Multiple containers may share the canonical database only as intentional stateless replicas. Required proof:

- same immutable image digest;
- same dependency lock;
- same configuration and policy digests;
- same schema compatibility;
- same tool snapshot;
- same authn/authz behavior;
- one routing authority and health policy;
- no local mutable state that changes semantics;
- idempotency and transaction behavior under concurrent delivery.

Until that proof exists, use one target canonical process. Twin surfaces with different compose/image provenance are forbidden.

## 4. Instance lifecycle

| Operation | Rule |
|---|---|
| Create | Trusted registry creates an explicit instance with project/workspace, actor/client, branch/worktree/commit evidence, purpose, and expiry. |
| Fork | Creates a child instance with `parent_instance_id`; no records are copied into a new identity silently. |
| Handoff | Grants bounded visibility or continuation to a named target instance, exact records/operations, and expiry. |
| Promote | Creates new durable revisions or grants in workspace scope while retaining `origin_project_id`, `origin_workspace_id`, `origin_instance_id`, actor, client, commit, request, and source revision. |
| Merge | Requires a deterministic merge plan, human approval, revision checks, per-record resolution, and an immutable receipt. |
| Supersede | Creates a new revision/object and marks the old one superseded atomically; history remains readable. |
| Archive | Revokes ordinary grants and closes the instance without deleting provenance. |
| Delete | Registry hard deletion is normally forbidden. Sensitive purge follows retention/legal policy and preserves a non-sensitive tombstone/audit proof. |

Temporary active context is instance-scoped by default. Another instance sees it only through an explicit unexpired grant or reviewed promotion. Durable product context and accepted decisions are workspace-visible subject to policy.

## 5. Canonical object model

### ConPort-owned objects

- `decision` and immutable `decision_revision`
- `decision_approval`
- `product_context` and revisions
- `active_context` and lease-bound revisions
- `progress_observation` / `work_evidence`
- allowlisted `custom_data` records and revisions
- typed `relationship_assertion` records
- stable external authority references
- idempotency records
- audit and policy-decision records
- transaction outbox events
- quarantine records and adjudication
- projection checkpoints

### Not ConPort-owned

- task status, transition legality, blockers, queue, completion authority, next action;
- passive PM metadata owned by Leantime;
- dope-memory chronology;
- dope-context ranking and semantic similarity;
- source code truth;
- bridge routing state;
- DCP policy-facade output;
- graph topology or vector neighborhoods;
- raw scratch notes;
- secrets or credentials;
- large binary artifacts.

## 6. Progress decision

The generic word `progress` is retired from authority prose and normalized tools except where explaining legacy compatibility.

ConPort records **observations**, not workflow truth. A valid observation states what was attempted or evidenced and references source artifacts, commits, tests, task/workflow IDs, or operator statements. Allowed classes include:

- `started`
- `advanced`
- `blocked_evidence`
- `completed_evidence`
- `handoff`
- `rollback`

A ConPort observation cannot transition a task, resolve a blocker, mark a workflow complete, reorder a queue, approve a step, or compute next action. Those calls route to Task Orchestrator.

## 7. Decision lifecycle

The target adopts bounded Nauro-like mechanics without taking a product dependency:

1. Run `conport.decision.conflicts` before a technical proposal that changes architecture, data, API, security, dependency, runtime, or authority.
2. Retrieval is advisory. The agent reads related decisions and reasons; similarity does not judge a conflict.
3. Create a `proposed` decision only after showing the draft to a human under the agent policy.
4. Transition `proposed` to `accepted` only with a digest-bound server-verified human approval.
5. Material changes to an accepted decision create an atomic supersession. The old decision remains immutable and cross-linked.
6. Deterministic JSONL plus Markdown export preserves human readability, provenance, and portability.
7. Server-side policy, not agent obedience, enforces the approval and supersession boundary.

## 8. Tool and audience surfaces

The normalized contract is defined in `CONPORT-NORMALIZED-TOOL-CONTRACT.json`.

### Claude Code and Codex

- Same canonical tool names and schemas.
- Bounded reads and policy-gated proposal/evidence/active-context writes.
- No approval, quarantine, import-apply, restore, projection-admin, identity-admin, or destructive admin tools.
- Client configuration controls reachability but does not enforce authority.

### DCP

- Read-only, redacted subset.
- Identity required on every read.
- No direct database access.
- No raw sensitive export.
- No agent/admin write aliases.

### Internal services

- Exact service allowlists and scoped credentials.
- Same policy engine and identity checks.
- dopecon-bridge may translate protocols but may not mutate canonical tables directly.

### Operator admin

- Separate CLI or authenticated control API.
- Stronger human and independent-review requirements.
- Full audit trail.
- Not listed in agent MCP discovery.

## 9. Storage and schema topology

Recommended physical baseline:

- PostgreSQL database: `dopemux_conport`
- Canonical schema: `conport_v2`
- Quarantine schema or tables: access restricted to admin role
- Projection schemas: distinct roles and no write rights to canonical tables
- Test database/schema/role: physically separate from production
- Transaction outbox: same transaction as canonical revision
- Migration ledger: target-specific, immutable checksum bundle, operator-gated

The legacy shared `public` schema is not upgraded in place as a convenience. Target migration exports, classifies, validates, and imports into the isolated schema.

## 10. Event, mirror, and projection model

### Canonical event

Every committed revision inserts an outbox row in the same transaction. Minimum fields:

- event ID, type, schema version, sequence, occurrence time;
- aggregate type, ID, revision, operation;
- project/workspace/instance identity;
- actor/client/request/idempotency IDs;
- commit/branch/worktree/task-packet provenance;
- source record URI and payload digest;
- redacted summary and sensitivity;
- supersedes/tombstone fields;
- policy decision ID.

### Failure semantics

- If the canonical record or outbox insert fails, the whole transaction fails.
- After commit, consumer failure does not roll back the canonical record.
- Delivery retries from the durable outbox.
- Duplicate delivery returns an idempotent receipt.
- Exhausted retries move to dead letter and alert an operator.
- No canonical event is dropped by UI rate-limit policy.

### Projections

- Native FTS, dope-context, AGE, Qdrant, caches, and rollups track a source snapshot and ordered event cursor.
- Supersession and deletion emit tombstones.
- Rebuild uses deterministic canonical export plus ordered events.
- Projection output includes generation, cursor, freshness, source refs, and advisory status.
- A stale projection may be bypassed by a canonical read if policy and budget allow; it may not invent or retain deleted authority.

## 11. Security boundary

- Loopback or Unix socket by default.
- Authenticated private network only when remote service access is necessary.
- No `0.0.0.0`/`::` canonical exposure without authenticated gateway, TLS where applicable, and independent security acceptance.
- No ambient trust in compose, container, port, path, or environment.
- Least-privilege database roles and RLS.
- No secrets in ConPort records, exports, event summaries, proofs, or logs.
- Deterministic deny decisions live in the policy engine. LLM guidance may advise but never carries the only deny.
- Rate limiting applies per actor/client/scope. It must not create cross-tenant timing or count disclosure.
- All admin operations are audited and require stronger approval.

## 12. Package and update policy

A target build is acceptable only when the following are bound into one runtime identity record:

```text
git_sha
lockfile_sha256
oci_image_digest
sbom_digest
configuration_sha256
policy_bundle_sha256
tool_contract_sha256
schema_bundle_sha256
migration_bundle_sha256
```

Rules:

- no floating `main`, image tag, package range, or unpinned `uvx` in production;
- source and image reproducibility must be demonstrated;
- dependency and protocol updates are separate reviewed packets;
- generated client config references immutable catalog entries;
- runtime `/info` or diagnostics report pins but do not grant authority;
- rollback restores the last accepted epoch, not merely an older container tag.

## 13. Migration and rollback boundary

- Freeze legacy writes before final export.
- Verify backup and isolated restore before migration.
- Classify every legacy row.
- Resolve aliases only from evidence.
- Quarantine ambiguous, foreign-project, system, and test data.
- Import into isolated target with original source IDs/digests and explicit migration provenance.
- Shadow-read and compare before cutover.
- Never dual-write two canonical stores.
- Final delta runs under write stop.
- Cutover sets a new target epoch and one write route.
- Cleanup waits until the rollback window closes and independent reconciliation passes.

Rollback cannot cross an irreversible schema or destructive cleanup boundary without restoring a verified backup. Stop target writes first, preserve outbox/idempotency evidence, restore the last accepted epoch, and reconcile any committed events.

## 14. Machine-checkable architecture invariants

1. `ARCH-001`: exactly one logical service identity is marked canonical for ConPort records.
2. `ARCH-002`: every canonical record has non-null project_id and workspace_id.
3. `ARCH-003`: every canonical operation returns a resolved identity envelope.
4. `ARCH-004`: every write has non-null instance_id, actor_id, client_id, request_id, idempotency_key, commit_sha, worktree_ref, and registry_generation.
5. `ARCH-005`: no path, port, container, compose project, current directory, or environment value alone authorizes a call.
6. `ARCH-006`: alias collisions fail closed and create no namespace.
7. `ARCH-007`: test/fixture identities cannot be registered in the production registry.
8. `ARCH-008`: promotion and merge preserve origin identity and revision provenance.
9. `ARCH-009`: ConPort progress observations cannot mutate Task Orchestrator state.
10. `ARCH-010`: accepted decisions require a valid human approval record.
11. `ARCH-011`: supersession changes old and new decision state atomically.
12. `ARCH-012`: canonical write and outbox insertion are atomic.
13. `ARCH-013`: no canonical event is subject to lossy UI-event dropping or semantic coalescing.
14. `ARCH-014`: every projection is rebuildable from a canonical snapshot and ordered events.
15. `ARCH-015`: projection output is labeled advisory and carries source provenance and freshness.
16. `ARCH-016`: DCP has no write or direct database route.
17. `ARCH-017`: admin tools are absent from agent tool discovery.
18. `ARCH-018`: SSE is absent from the target transport set.
19. `ARCH-019`: no target dependency or image is floating.
20. `ARCH-020`: no Wave 2+ execution begins before exact ADR acceptance and separate authorization.

## 15. Open unknowns

- Exact target git SHA, lockfile, image, SBOM, configuration, policy, schema, and migration digests.
- Exact target package/module layout and final entrypoint names.
- Whether native FTS is sufficient or a separate projection is justified after tests.
- Whether any replica topology is operationally worthwhile.
- Exact retention values, RPO, RTO, and legal-hold requirements.
- Exact auth provider and approval-token signing mechanism.
- Live current state of Hue's Docker runtime after the candidate collection timestamp.
- Whether any dark port 3005/4004 surface has changed locally.

These unknowns are carried into gated waves. None is silently resolved by this document.
