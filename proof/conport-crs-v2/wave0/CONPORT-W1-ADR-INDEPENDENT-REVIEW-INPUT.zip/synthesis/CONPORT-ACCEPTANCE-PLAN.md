# ConPort Acceptance Plan

**Target:** Dopemux ConPort Canonical Record Service v2  
**Plan status:** Proposed  
**Current overall acceptance:** `NOT_ACCEPTED_FOR_IMPLEMENTATION`  
**Allowed statuses:** `PASS`, `FAIL`, `NOT_RUN`

## 1. Evidence rules

- `PASS` means the named gate was actually executed for the stated scope and satisfied its exact criteria.
- `FAIL` means evidence establishes a defect or a required criterion is unmet.
- `NOT_RUN` means the target test has not been executed or the target component does not exist.
- A pass for input custody or static architecture does not pass a target runtime gate.
- A pass for a current baseline snapshot does not pass future target compatibility.
- A stale pass returns to `NOT_RUN` when a material pin, schema, policy, tool contract, identity rule, transport, client, or topology changes.
- Screenshots, prose assertions, and configuration presence are not substitutes for machine-readable test evidence where deterministic proof is possible.
- Negative tests must show both the typed denial and zero foreign-scope disclosure.

## 2. Current gate matrix

| ID | Gate | Status | Scope | Evidence basis |
|---|---|---|---|---|
| `GATE-001` | input custody | **PASS** | `synthesis_input` | ZIP SHA-256 40972f2d5db05b7ca436ea55998d902ef18be3219e7ea68832668c85b8ad39be, 29,108 bytes, matching sidecar, clean CRC, safe relative paths, no symlinks, no normalized-path collisions, exact six required research artifacts. Package manifest was absent and allowed by the file-set clause. |
| `GATE-002` | source and runtime identity | **FAIL** | `current_baseline` | Public source identities were reverified at Dopemux 5a9f8f7b5d4a03be323723a92baf3c4e162d5b65 and upstream 18bde469feb03c233d11c9a4941bd27bd859a5ff; local runtime evidence identifies two healthy shadow-twin containers but proves no canonical runtime identity, immutable image policy, or single authority endpoint. |
| `GATE-003` | static architecture rules | **PASS** | `synthesis_artifacts` | Target artifacts name one canonical service, stable identity, authority boundaries, no direct database clients, derived projections, ADR gating, and no implementation authorization. |
| `GATE-004` | tool-surface snapshot | **PASS** | `current_baseline_static_and_collected_runtime` | Candidate runtime probe captured 13 conport_* tools on the port 3004 JSON-RPC compatibility endpoint; source paths for custom, stdio, and enhanced surfaces were reopened. This pass does not validate the unbuilt target surface. |
| `GATE-005` | schema compatibility | **FAIL** | `current_baseline` | Current shared public schema uses raw workspace strings, nullable instance fields, mutable progress semantics, seed/test residue, and no demonstrated RLS or target identity registry. |
| `GATE-006` | live MCP handshakes | **NOT_RUN** | `target_runtime` | Target runtime does not exist. Port 3004 was not an MCP lifecycle endpoint; 3005 and initialized stdio remained unproven in collected evidence. |
| `GATE-007` | multi-project isolation | **FAIL** | `current_baseline` | The shared store contains Dopemux, adOps, _system, packet, alias, and pytest path identities; 14 of 15 progress rows belong to adOps. |
| `GATE-008` | multi-workspace isolation | **FAIL** | `current_baseline` | Absolute paths, short names, packet identifiers, and aliases coexist as workspace keys without a canonical registry. |
| `GATE-009` | multi-instance isolation | **FAIL** | `current_baseline` | 13 of 15 progress rows and both workspace-context rows have null instance_id; current defaults cannot reconstruct provenance. |
| `GATE-010` | wrong-workspace negative tests | **NOT_RUN** | `target_runtime` | No controlled target fixture was executed. |
| `GATE-011` | wrong-instance negative tests | **NOT_RUN** | `target_runtime` | No controlled target fixture was executed. |
| `GATE-012` | identity alias collisions | **NOT_RUN** | `target_runtime` | Design specifies normalization, but no target resolver exists. |
| `GATE-013` | decision conflict and supersession | **NOT_RUN** | `target_runtime` | Tool contract is proposed only. |
| `GATE-014` | progress authority | **FAIL** | `current_baseline` | Current progress rows use broad state labels and no evidence proves enforcement against Task Orchestrator authority. |
| `GATE-015` | active-context visibility | **NOT_RUN** | `target_runtime` | Target lease, grant, expiry, and closeout behavior is unimplemented. |
| `GATE-016` | FTS and vector update/delete consistency | **NOT_RUN** | `target_runtime_and_projections` | Current Qdrant use is unproven and target projections do not exist. |
| `GATE-017` | mirror delivery and replay | **NOT_RUN** | `target_runtime_and_dope_memory` | No current event emission or mirror receipt was proven. |
| `GATE-018` | backup and restore | **NOT_RUN** | `target_runtime` | No target backup or isolated restore drill exists. |
| `GATE-019` | deterministic export/import | **NOT_RUN** | `target_runtime` | The proposed JSONL plus Markdown format is not implemented. |
| `GATE-020` | contaminated-data migration | **NOT_RUN** | `target_migration` | Current contamination is observed, but classification and quarantine have not run. |
| `GATE-021` | Claude Code behavioral trial | **NOT_RUN** | `target_agent_surface` | Target launcher and policy are not implemented. |
| `GATE-022` | Codex behavioral trial | **NOT_RUN** | `target_agent_surface` | Target launcher and policy are not implemented. |
| `GATE-023` | DCP read-only trial | **NOT_RUN** | `target_dcp_surface` | Target redacted facade is not implemented. |
| `GATE-024` | performance budgets | **NOT_RUN** | `target_runtime` | Budgets are specified but no load tests exist. |
| `GATE-025` | security review | **FAIL** | `current_baseline` | One live container binds 3004, 3005, and 4004 on 0.0.0.0 and ::; no authoritative auth challenge or tenant policy was proven. |
| `GATE-026` | rollback rehearsal | **NOT_RUN** | `target_runtime_and_migration` | No target deployment or migration exists. |

## 3. Gate specifications

### GATE-001: input custody - `PASS`

**Scope:** `synthesis_input`

**Current evidence:** ZIP SHA-256 40972f2d5db05b7ca436ea55998d902ef18be3219e7ea68832668c85b8ad39be, 29,108 bytes, matching sidecar, clean CRC, safe relative paths, no symlinks, no normalized-path collisions, exact six required research artifacts. Package manifest was absent and allowed by the file-set clause.

**Exact PASS criteria:** Every custody check succeeds and all internal artifact byte counts and hashes match.

**Failure effect:** Stop with BLOCKED_INPUT_CUSTODY.

### GATE-002: source and runtime identity - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** Public source identities were reverified at Dopemux 5a9f8f7b5d4a03be323723a92baf3c4e162d5b65 and upstream 18bde469feb03c233d11c9a4941bd27bd859a5ff; local runtime evidence identifies two healthy shadow-twin containers but proves no canonical runtime identity, immutable image policy, or single authority endpoint.

**Exact PASS criteria:** One target runtime has immutable git, lock, image, schema, configuration, and policy digests, and no second surface can claim canonical authority.

**Failure effect:** No runtime cutover or implementation-ready claim.

### GATE-003: static architecture rules - `PASS`

**Scope:** `synthesis_artifacts`

**Current evidence:** Target artifacts name one canonical service, stable identity, authority boundaries, no direct database clients, derived projections, ADR gating, and no implementation authorization.

**Exact PASS criteria:** Automated lint confirms all mandatory architecture decisions and prohibitions are represented without internal contradiction.

**Failure effect:** Repair synthesis artifacts before independent review.

### GATE-004: tool-surface snapshot - `PASS`

**Scope:** `current_baseline_static_and_collected_runtime`

**Current evidence:** Candidate runtime probe captured 13 conport_* tools on the port 3004 JSON-RPC compatibility endpoint; source paths for custom, stdio, and enhanced surfaces were reopened. This pass does not validate the unbuilt target surface.

**Exact PASS criteria:** A dated immutable snapshot exists with endpoint classification, tool names, schemas where available, and source/runtime provenance.

**Failure effect:** Do not map legacy clients or claim compatibility.

### GATE-005: schema compatibility - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** Current shared public schema uses raw workspace strings, nullable instance fields, mutable progress semantics, seed/test residue, and no demonstrated RLS or target identity registry.

**Exact PASS criteria:** Target schema bundle passes structural, migration, RLS, revision, outbox, quarantine, and compatibility tests.

**Failure effect:** No canonical migration or write cutover.

### GATE-006: live MCP handshakes - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** Target runtime does not exist. Port 3004 was not an MCP lifecycle endpoint; 3005 and initialized stdio remained unproven in collected evidence.

**Exact PASS criteria:** Initialize, capabilities, tools/list, representative reads, representative gated writes, cancellation, errors, and shutdown pass on every authorized target transport.

**Failure effect:** No agent trial or cutover.

### GATE-007: multi-project isolation - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** The shared store contains Dopemux, adOps, _system, packet, alias, and pytest path identities; 14 of 15 progress rows belong to adOps.

**Exact PASS criteria:** RLS and policy tests prove zero cross-project reads, writes, searches, counts, timing leaks, and projection leakage.

**Failure effect:** Canonical multi-project hosting prohibited.

### GATE-008: multi-workspace isolation - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** Absolute paths, short names, packet identifiers, and aliases coexist as workspace keys without a canonical registry.

**Exact PASS criteria:** One canonical workspace_id per logical workspace, deterministic alias resolution, collision denial, scoped credentials, and negative search tests all pass.

**Failure effect:** Shared multi-workspace service prohibited.

### GATE-009: multi-instance isolation - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** 13 of 15 progress rows and both workspace-context rows have null instance_id; current defaults cannot reconstruct provenance.

**Exact PASS criteria:** Instance visibility, grants, handoff, promotion, merge, archive, and denial tests pass with preserved origin provenance.

**Failure effect:** Instance-scoped writes and shared visibility prohibited.

### GATE-010: wrong-workspace negative tests - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** No controlled target fixture was executed.

**Exact PASS criteria:** Every read, write, search, batch, export, adapter, admin, and projection route returns WORKSPACE_MISMATCH or POLICY_DENIED and exposes zero foreign records.

**Failure effect:** Stop rollout and treat as a security incident.

### GATE-011: wrong-instance negative tests - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** No controlled target fixture was executed.

**Exact PASS criteria:** Cross-instance access fails unless an unexpired explicit grant covers the exact object and operation; promotion preserves origin.

**Failure effect:** Stop rollout and disable instance sharing.

### GATE-012: identity alias collisions - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** Design specifies normalization, but no target resolver exists.

**Exact PASS criteria:** Absolute path, realpath, symlink, case, short name, remote URL, repo marker, worktree, and packet aliases resolve to one identity or fail closed. No silent namespace creation.

**Failure effect:** No migration or write enablement.

### GATE-013: decision conflict and supersession - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** Tool contract is proposed only.

**Exact PASS criteria:** Conflict check is required and fresh; acceptance requires human approval; supersession is atomic, bidirectional, immutable, idempotent, and export-visible.

**Failure effect:** Decision writes remain disabled.

### GATE-014: progress authority - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** Current progress rows use broad state labels and no evidence proves enforcement against Task Orchestrator authority.

**Exact PASS criteria:** Target accepts only typed observations/work evidence; attempts to change workflow state through ConPort are deterministically denied.

**Failure effect:** Progress migration and agent writes remain disabled.

### GATE-015: active-context visibility - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** Target lease, grant, expiry, and closeout behavior is unimplemented.

**Exact PASS criteria:** Default visibility is owning instance only; explicit grants are bounded, expiring, auditable, and revocable; closed context is not silently reactivated.

**Failure effect:** Active-context writes remain disabled.

### GATE-016: FTS and vector update/delete consistency - `NOT_RUN`

**Scope:** `target_runtime_and_projections`

**Current evidence:** Current Qdrant use is unproven and target projections do not exist.

**Exact PASS criteria:** Create, update, supersede, delete/tombstone, replay, and rebuild yield identical visible results and provenance. Vector additionally passes privacy and deterministic tie-break gates.

**Failure effect:** Vector remains disabled; stale FTS projection cannot serve authoritative reads.

### GATE-017: mirror delivery and replay - `NOT_RUN`

**Scope:** `target_runtime_and_dope_memory`

**Current evidence:** No current event emission or mirror receipt was proven.

**Exact PASS criteria:** Canonical write and outbox are atomic; duplicate delivery is idempotent; outage queues; replay converges; dead letters alert; receipts match source digests.

**Failure effect:** No mirror cutover; canonical writes may proceed only if accepted policy permits queued outbox and backlog stays bounded.

### GATE-018: backup and restore - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** No target backup or isolated restore drill exists.

**Exact PASS criteria:** Encrypted backup verifies, isolated restore reaches the same accepted schema and record digests, RPO/RTO are measured, and secret material is excluded from artifacts.

**Failure effect:** No migration or production cutover.

### GATE-019: deterministic export/import - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** The proposed JSONL plus Markdown format is not implemented.

**Exact PASS criteria:** Same snapshot and redaction profile produce byte-identical exports; validation is side-effect free; import plan and apply are digest-bound and idempotent.

**Failure effect:** No portability claim or bulk migration.

### GATE-020: contaminated-data migration - `NOT_RUN`

**Scope:** `target_migration`

**Current evidence:** Current contamination is observed, but classification and quarantine have not run.

**Exact PASS criteria:** Every source row is classified as canonical-safe, alias-resolvable, instance-scoped, packet-scoped, foreign-project, system, test/fixture, or ambiguous; ambiguous data is quarantined; no provenance is invented.

**Failure effect:** Stop migration before canonical import.

### GATE-021: Claude Code behavioral trial - `NOT_RUN`

**Scope:** `target_agent_surface`

**Current evidence:** Target launcher and policy are not implemented.

**Exact PASS criteria:** Claude resolves identity, performs bounded retrieval, checks conflicts, seeks approval, records only meaningful observations, protects wrong workspace, and completes handoff within budgets.

**Failure effect:** Claude write surface remains disabled.

### GATE-022: Codex behavioral trial - `NOT_RUN`

**Scope:** `target_agent_surface`

**Current evidence:** Target launcher and policy are not implemented.

**Exact PASS criteria:** Codex satisfies the same behavioral and security assertions independently, including no write when approval or identity is stale.

**Failure effect:** Codex write surface remains disabled.

### GATE-023: DCP read-only trial - `NOT_RUN`

**Scope:** `target_dcp_surface`

**Current evidence:** Target redacted facade is not implemented.

**Exact PASS criteria:** DCP exposes only allowlisted redacted reads, requires identity on every call, denies all writes/admin/export-sensitive paths, and has no direct database route.

**Failure effect:** DCP ConPort exposure remains disabled.

### GATE-024: performance budgets - `NOT_RUN`

**Scope:** `target_runtime`

**Current evidence:** Budgets are specified but no load tests exist.

**Exact PASS criteria:** Tool p95 and inline result limits pass under representative concurrent multi-workspace load, with RLS enabled and projection lag bounded.

**Failure effect:** No production readiness claim; tune or narrow surface without relaxing isolation.

### GATE-025: security review - `FAIL`

**Scope:** `current_baseline`

**Current evidence:** One live container binds 3004, 3005, and 4004 on 0.0.0.0 and ::; no authoritative auth challenge or tenant policy was proven.

**Exact PASS criteria:** Threat model, loopback/private binding, authn, authz, RLS, secret handling, audit, rate limits, denial tests, and dependency pin review are independently accepted.

**Failure effect:** No target network exposure or production cutover.

### GATE-026: rollback rehearsal - `NOT_RUN`

**Scope:** `target_runtime_and_migration`

**Current evidence:** No target deployment or migration exists.

**Exact PASS criteria:** Writes stop, last accepted application/schema epoch restores, queued events reconcile, agents revert to read-only or disabled mode, and no irreversible boundary is crossed without restore proof.

**Failure effect:** No cutover.

## 4. Mandatory negative-test suite

The target suite must include at least these cases across direct agent, DCP, internal adapter, mirror, projection, batch, export, and admin routes where applicable:

1. wrong `project_id` read and write;
2. wrong `workspace_id` read and write;
3. wrong `instance_id` read and write without grant;
4. absolute-path alias to another project;
5. symlink alias collision;
6. case-folding collision;
7. short-name collision;
8. forged actor identity;
9. forged client identity;
10. stale registry generation;
11. stale commit and unrelated commit;
12. unregistered worktree/branch;
13. expired or scope-mismatched handoff grant;
14. production request using test/pytest/temp namespace;
15. cross-workspace search returning zero results and no count/timing disclosure;
16. batch containing one foreign-scope operation rolls back or denies safely;
17. export cannot include foreign or quarantined data;
18. DCP write and admin aliases denied;
19. bridge direct-database or scope override denied;
20. mirror consumer cannot write canonical records;
21. projection query cannot bypass RLS or return tombstoned records;
22. duplicate idempotency key with changed payload denied;
23. decision approval with forged, expired, consumed, or wrong-digest token denied;
24. supersession half-state impossible under injected failure;
25. progress observation attempting workflow transition denied;
26. active context from another instance invisible without grant;
27. promotion preserves origin project/workspace/instance/actor/client/commit;
28. merge requires deterministic plan and approval;
29. global unauthenticated route cannot reach canonical tools;
30. stateless replicas, if used, return equivalent authorization and receipts.

## 5. Decision and supersession acceptance cases

Required positive cases:

- conflict check returns deterministic exact-key conflicts plus advisory related decisions;
- no related result is described as proof of no conflict;
- proposal remains `proposed` after agent write;
- authorized approval transitions exactly one proposal revision to accepted;
- approval is digest-bound and single-use;
- supersession creates the replacement and marks the old decision superseded atomically;
- old and new records cross-reference each other;
- history and deterministic export show the full lineage;
- concurrent proposals use revision and conflict checks rather than last-write-wins.

Required failures:

- agent calls approval/supersession;
- stale conflict-check ID;
- material update attempted as rationale-only correction;
- half-supersession under fault injection;
- approval from wrong project/workspace or actor role.

## 6. Progress authority acceptance cases

- every record uses an allowlisted observation type;
- evidence reference is required;
- workflow-like mutation fields are rejected;
- status, blocker, queue, approval, completion, and next-action attempts route to Task Orchestrator or fail;
- migration does not infer workflow state from legacy labels;
- correction appends a revision and preserves the original;
- activity summary labels observations as non-workflow authority.

## 7. Active-context acceptance cases

- default read returns only the owning instance context;
- another instance receives no existence leak without a grant;
- bounded grants expire and revoke correctly;
- close prevents default active retrieval;
- no read creates/resumes/forks an instance;
- promotion creates new visibility/revision while preserving origin;
- payload and lease limits are enforced;
- stale context is labeled and cannot silently drive a durable material write.

## 8. Projection and mirror acceptance cases

### Event/outbox

- canonical revision and outbox insert commit atomically;
- outbox-insert failure rolls back the revision;
- post-commit consumer outage queues rather than loses;
- duplicate and out-of-order delivery converge;
- retry exhaustion produces dead letter and alert;
- receipts carry matching source digest and identity digest;
- canonical events are not dropped or semantically coalesced by ADR-221 UI policy.

### FTS/dope-context/graph/vector

- create appears after accepted lag;
- update replaces old content;
- supersession changes active filtering;
- deletion/tombstone removes ordinary visibility;
- replay from checkpoint converges;
- full rebuild from snapshot plus events is equivalent;
- cross-workspace query has zero leakage;
- every result has source revision, generation, cursor/freshness, and advisory label;
- vector stays disabled until privacy and all consistency cases pass.

## 9. Backup, restore, export, import, and rollback

### Backup/restore

- backup is encrypted and content-addressed;
- roles, RLS, extensions, schema, policy, and migration digests are captured;
- isolated restore starts with no production credentials;
- record/revision/decision/outbox/receipt counts and digests reconcile;
- RPO/RTO are measured;
- restore does not expose quarantined records to ordinary roles.

### Export/import

- same snapshot/profile yields byte-identical output;
- decisions and product context are human-readable;
- secret/path redaction is deterministic;
- validation is side-effect free;
- apply is digest-bound, approval-gated, idempotent, and backup-gated;
- ambiguous identities quarantine rather than import;
- reimport does not duplicate records.

### Rollback

- target writes stop first;
- committed event cursor is captured;
- accepted epoch restores;
- clients revert to disabled/read-only or approved fallback;
- outbox/idempotency reconciliation prevents duplicate writes;
- projections rebuild from chosen canonical epoch;
- failed gates are reset and incident evidence preserved.

## 10. Performance budgets

The tool contract contains per-tool p95 and inline result budgets. The acceptance workload must include:

- representative single-workspace reads/writes;
- concurrent multi-workspace traffic with RLS;
- search and history at upper bounded result size;
- idempotency replay;
- decision approval/supersession;
- outbox backlog and consumer recovery;
- projection lag and rebuild;
- Claude/Codex bootstrap budget;
- DCP redacted read budget;
- admin backup/export returning artifact references rather than giant inline payloads.

Performance optimization may not disable RLS, remove identity checks, relax result isolation, expose caches as authority, or drop canonical events.

## 11. Required cutover status

Before cutover, every gate from `GATE-002` through `GATE-026` that applies to the selected topology must be `PASS`. `GATE-001`, `GATE-003`, and `GATE-004` must also remain valid and fresh.

Current state includes multiple `FAIL` and `NOT_RUN` gates. Therefore:

```text
IMPLEMENTATION_ACCEPTANCE = DENIED
CUTOVER_ACCEPTANCE = DENIED
LEGACY_CLEANUP_ACCEPTANCE = DENIED
ADR_INDEPENDENT_REVIEW = READY
```

## 12. Evidence package requirements

Each executed gate records:

- gate ID and status;
- exact target git, lock, image, configuration, policy, tool, schema, and migration digests;
- environment classification;
- test command and test artifact digest;
- start/end timestamps;
- actor/executor and independent reviewer;
- fixtures and project/workspace/instance IDs;
- expected and actual result;
- sanitized logs and machine-readable results;
- unresolved deviations;
- linked incident or waiver, if any.

A waiver cannot turn a failed isolation, authorization, backup, approval, or rollback gate into a pass. It must change the architecture or block rollout.
