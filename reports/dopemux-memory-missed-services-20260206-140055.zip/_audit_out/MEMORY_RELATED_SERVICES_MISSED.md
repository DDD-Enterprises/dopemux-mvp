# Memory-Related Services Missed by Registry (Separate Set)

## Method
- Compared `services/registry.yaml` against `services/` directory entries for memory/context/intelligence-adjacent names.

## Found in `services/` (candidate memory/context set)
- `conport`
- `dope-query`
- `dope-context`
- `working-memory-assistant`
- `dopecon-bridge`
- `claude_brain`
- `intelligence`
- `session-intelligence`
- `session_intelligence`

Evidence: `_audit_out/_sources/services_dir_listing.txt:7-13`, `_audit_out/_sources/services_dir_listing.txt:18`, `_audit_out/_sources/services_dir_listing.txt:26-28`, `_audit_out/_sources/services_dir_listing.txt:36`

## Present in registry memory-adjacent entries
- `dope-query` (ConPort runtime)
- `dope-memory`
- `dopecon-bridge`
- `redis`
- `qdrant`
- `adhd-engine` + ADHD adjunct services

Evidence: `services/registry.yaml:44-76`, `services/registry.yaml:89-117`, `services/registry.yaml:134-158`, `services/registry.yaml:246-268`

## Missing in registry (candidate drift)
- `dope-context` (directory exists; no `name: dope-context` in current registry file)
- `working-memory-assistant` (registry names it `dope-memory`, likely alias)
- `claude_brain`, `intelligence`, `session-intelligence`, `session_intelligence` (existence shown, not registry-declared)

Evidence: `_audit_out/_sources/services_dir_listing.txt:7`, `_audit_out/_sources/services_dir_listing.txt:12`, `_audit_out/_sources/services_dir_listing.txt:18`, `_audit_out/_sources/services_dir_listing.txt:26-28`, `_audit_out/_sources/services_dir_listing.txt:36`, `services/registry.yaml:20-293`
