"""Pytest configuration for dopecon-bridge tests."""

import sys
from pathlib import Path


SERVICE_ROOT = Path(__file__).resolve().parent.parent
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
